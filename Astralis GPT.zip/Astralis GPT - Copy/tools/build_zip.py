from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "dist" / "Astralis_GPT_0.1.0.zip"
INCLUDED = ("shaders", "README.md", "LICENSE")
FIXED_TIME = (2026, 1, 1, 0, 0, 0)


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED) as archive:
        for relative in INCLUDED:
            source = ROOT / relative
            if source.is_dir():
                archive.writestr(ZipInfo(f"{relative}/", FIXED_TIME), b"")
                for path in sorted(source.rglob("*")):
                    if path.is_dir():
                        archive.writestr(
                            ZipInfo(f"{path.relative_to(ROOT).as_posix()}/", FIXED_TIME), b""
                        )
                    elif path.is_file():
                        info = ZipInfo(path.relative_to(ROOT).as_posix(), FIXED_TIME)
                        info.compress_type = ZIP_DEFLATED
                        archive.writestr(info, path.read_bytes())
            elif source.is_file():
                info = ZipInfo(relative, FIXED_TIME)
                info.compress_type = ZIP_DEFLATED
                archive.writestr(info, source.read_bytes())
            else:
                raise FileNotFoundError(source)

    with ZipFile(OUTPUT) as archive:
        names = archive.namelist()
        if not any(name.startswith("shaders/") for name in names):
            raise RuntimeError("Archive is missing the shaders/ root directory")
        if any("\\" in name for name in names):
            raise RuntimeError("Archive contains a backslash path")
    print(f"Built and inspected: {OUTPUT}")


if __name__ == "__main__":
    main()

