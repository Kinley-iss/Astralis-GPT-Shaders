from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parent.parent
SHADERS = ROOT / "shaders"
PROPERTIES = SHADERS / "shaders.properties"
PROGRAMS = (
    "gbuffers_terrain",
    "gbuffers_entities",
    "gbuffers_textured",
    "gbuffers_textured_lit",
    "gbuffers_water",
    "gbuffers_skybasic",
    "gbuffers_skytextured",
    "composite",
    "final",
)
IRIS_PROFILE_SETTINGS = {"shadowMapResolution", "shadowDistance"}


def lint_options() -> list[str]:
    errors: list[str] = []
    option_pattern = re.compile(
        r"^\s*#define\s+([A-Z][A-Z0-9_]*)"
        r"(?:\s+([^\s/]+))?\s*//\s*(?:\[([^\]]+)\])?",
        re.MULTILINE,
    )
    options: dict[str, tuple[str | None, list[str]]] = {}
    shader_sources = list(SHADERS.rglob("*.glsl")) + list(SHADERS.rglob("*.fsh")) + list(SHADERS.rglob("*.vsh"))
    iris_constant_pattern = re.compile(
        r"^\s*const\s+(int|float)\s+(shadowMapResolution|shadowDistance)"
        r"\s*=\s*([^;]+)\s*;",
        re.MULTILINE,
    )
    iris_constant_defaults: dict[str, str] = {}
    for path in shader_sources:
        source = path.read_text(encoding="utf-8")
        for name, default, choices in option_pattern.findall(source):
            value = (default or None, choices.split() if choices else [])
            if name in options and options[name] != value:
                errors.append(f"Option {name} has inconsistent definitions.")
            options[name] = value
        for _, name, default in iris_constant_pattern.findall(source):
            if name in iris_constant_defaults and iris_constant_defaults[name] != default.strip():
                errors.append(f"Iris constant {name} has inconsistent defaults.")
            iris_constant_defaults[name] = default.strip()

    for name in sorted(IRIS_PROFILE_SETTINGS - iris_constant_defaults.keys()):
        errors.append(f"Missing Iris compile-time constant declaration for {name}.")

    if not PROPERTIES.is_file():
        return errors
    properties = {}
    for line in PROPERTIES.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            key, value = stripped.split("=", 1)
            if key.strip() in properties:
                errors.append(f"Duplicate shader property {key.strip()}.")
            properties[key.strip()] = value.strip()

    menu_options: set[str] = set()
    for key, value in properties.items():
        if key == "screen" or key.startswith("screen."):
            for token in value.split():
                if token.startswith("[") or token in ("<profile>", "<empty>", "*"):
                    continue
                menu_options.add(token)
        elif key == "sliders":
            menu_options.update(value.split())

    for option in sorted(menu_options - options.keys() - IRIS_PROFILE_SETTINGS):
        errors.append(f"Settings screen references undefined option {option}.")
    for option in sorted(options.keys() - menu_options):
        errors.append(f"Defined option {option} is not on the settings screen.")

    for profile in ("PERFORMANCE", "BALANCED", "QUALITY"):
        key = f"profile.{profile}"
        if key not in properties:
            errors.append(f"Missing {key}.")
            continue
        profile_values: dict[str, str | None] = {}
        for entry in properties[key].split():
            token = entry.lstrip("!")
            if ":" in token or "=" in token:
                name, value = re.split(r"[:=]", token, maxsplit=1)
                profile_values[name] = value
            else:
                profile_values[token] = None if entry.startswith("!") else "ON"
            name = token.split(":", 1)[0].split("=", 1)[0]
            if name not in options and name not in IRIS_PROFILE_SETTINGS:
                errors.append(f"{key} references undefined option {name}.")
            elif name in options and profile_values.get(name) is not None:
                choices = options[name][1]
                if choices and profile_values[name] not in choices:
                    errors.append(
                        f"{key} value {profile_values[name]} for {name} is not in {choices}."
                    )

        missing_profile_options = (options.keys() | IRIS_PROFILE_SETTINGS) - profile_values.keys()
        if missing_profile_options:
            errors.append(
                f"{key} omits options: {', '.join(sorted(missing_profile_options))}."
            )

        if profile == "BALANCED":
            for option, (default, _) in options.items():
                configured = profile_values.get(option)
                expected = default if default is not None else "ON"
                if configured != expected:
                    errors.append(
                        f"{option} default {expected!r} differs from Balanced value {configured!r}."
                    )
            for setting in IRIS_PROFILE_SETTINGS:
                if profile_values.get(setting) != properties.get(setting):
                    errors.append(
                        f"{setting} default {properties.get(setting)!r} differs from "
                        f"Balanced value {profile_values.get(setting)!r}."
                    )
                if profile_values.get(setting) != iris_constant_defaults.get(setting):
                    errors.append(
                        f"{setting} GLSL constant {iris_constant_defaults.get(setting)!r} "
                        f"differs from Balanced value {profile_values.get(setting)!r}."
                    )

    for profile in ("PERFORMANCE", "BALANCED"):
        profile_values = dict(
            re.split(r"[:=]", entry, maxsplit=1)
            if ":" in entry or "=" in entry
            else (entry.lstrip("!"), "OFF" if entry.startswith("!") else "ON")
            for entry in properties.get(f"profile.{profile}", "").split()
        )
        if profile_values.get("SCREEN_TRACE_STEPS") != "0":
            errors.append(f"{profile} must keep SCREEN_TRACE_STEPS disabled.")
        if profile_values.get("PATH_TRACE_STRENGTH") != "0.00":
            errors.append(f"{profile} must keep PATH_TRACE_STRENGTH disabled.")

    quality_values = dict(
        re.split(r"[:=]", entry, maxsplit=1)
        if ":" in entry or "=" in entry
        else (entry.lstrip("!"), "OFF" if entry.startswith("!") else "ON")
        for entry in properties.get("profile.QUALITY", "").split()
    )
    if quality_values.get("SCREEN_TRACE_STEPS", "0") == "0":
        errors.append("QUALITY must enable screen-space ray tracing.")
    if quality_values.get("PATH_TRACE_STRENGTH", "0.00") == "0.00":
        errors.append("QUALITY must enable the one-bounce path-light approximation.")

    sliders = properties.get("sliders", "").split()
    for option in sliders:
        if option not in IRIS_PROFILE_SETTINGS and (
            option not in options or not options[option][1]
        ):
            errors.append(f"Slider {option} must be a defined numeric option with choices.")

    language = SHADERS / "lang" / "en_us.lang"
    if not language.is_file():
        errors.append("Missing shaders/lang/en_us.lang.")
    else:
        labels = {}
        for line in language.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                labels[key.strip()] = value.strip()
        for option in sorted(options.keys() | IRIS_PROFILE_SETTINGS):
            if f"option.{option}" not in labels:
                errors.append(f"Option {option} has no en_us label.")
            if f"option.{option}.comment" not in labels:
                errors.append(f"Option {option} has no en_us description.")
        for key in properties:
            if key.startswith("screen.") and key != "screen.columns":
                screen_name = key[len("screen."):]
                if f"screen.{screen_name}" not in labels:
                    errors.append(f"Settings screen {screen_name} has no en_us label.")
        all_source = "\n".join(path.read_text(encoding="utf-8") for path in shader_sources)
        for option in sorted(options):
            uses = [
                line
                for line in all_source.splitlines()
                if re.search(rf"\b{re.escape(option)}\b", line)
                and not re.match(rf"\s*#define\s+{re.escape(option)}\b", line)
                and not line.lstrip().startswith("//")
            ]
            if not uses:
                errors.append(f"Option {option} is defined but not consumed by shader code.")
    return errors


def resolve_includes(path: Path, stack: tuple[Path, ...] = ()) -> list[str]:
    if path in stack:
        raise ValueError(f"Recursive include: {path.relative_to(ROOT)}")
    source = path.read_text(encoding="utf-8")
    expanded = [source]
    for include in re.findall(r'^\s*#include\s+"([^"]+)"', source, re.MULTILINE):
        include_path = SHADERS / include.lstrip("/") if include.startswith("/") else path.parent / include
        if not include_path.is_file():
            raise FileNotFoundError(f"{path.relative_to(ROOT)} includes missing {include}")
        expanded.extend(resolve_includes(include_path, stack + (path,)))
    return expanded


def main() -> int:
    errors: list[str] = []
    for program in PROGRAMS:
        for stage in ("vsh", "fsh"):
            path = SHADERS / f"{program}.{stage}"
            if not path.is_file():
                errors.append(f"Missing shader stage: {path.relative_to(ROOT)}")
                continue
            source = path.read_text(encoding="utf-8")
            if not source.startswith("#version 120\n"):
                errors.append(f"{path.relative_to(ROOT)} must start with #version 120")
            if "void main()" not in source:
                errors.append(f"{path.relative_to(ROOT)} has no main function")
            if source.count("{") != source.count("}"):
                errors.append(f"Unbalanced braces in {path.relative_to(ROOT)}")
            try:
                resolve_includes(path)
            except (FileNotFoundError, ValueError) as error:
                errors.append(str(error))

        vertex_path = SHADERS / f"{program}.vsh"
        fragment_path = SHADERS / f"{program}.fsh"
        if vertex_path.is_file() and fragment_path.is_file():
            vertex = vertex_path.read_text(encoding="utf-8")
            fragment = fragment_path.read_text(encoding="utf-8")
            declaration = r"\bvarying\s+(\w+)\s+(\w+)\s*;"
            vertex_varyings = dict(re.findall(declaration, vertex))
            fragment_varyings = dict(re.findall(declaration, fragment))
            missing = fragment_varyings.keys() - vertex_varyings.keys()
            if missing:
                errors.append(
                    f"{program} fragment varyings missing from vertex shader: {', '.join(sorted(missing))}"
                )
            mismatched = {
                name
                for name in fragment_varyings.keys() & vertex_varyings.keys()
                if fragment_varyings[name] != vertex_varyings[name]
            }
            if mismatched:
                errors.append(
                    f"{program} varying types differ: {', '.join(sorted(mismatched))}"
                )

    shadow_stages = (SHADERS / "shadow.vsh", SHADERS / "shadow.fsh")
    for path in shadow_stages:
        if not path.is_file():
            errors.append(f"Missing shadow stage: {path.relative_to(ROOT)}")
        else:
            source = path.read_text(encoding="utf-8")
            if not source.startswith("#version 120\n") or "void main()" not in source:
                errors.append(f"{path.relative_to(ROOT)} has invalid basic GLSL structure")
            try:
                resolve_includes(path)
            except (FileNotFoundError, ValueError) as error:
                errors.append(str(error))

    if not (SHADERS / "shaders.properties").is_file():
        errors.append("Missing shaders/shaders.properties")
    errors.extend(lint_options())
    for required in ("README.md", "LICENSE", "docs/FEATURE_MATRIX.md", "docs/IRIS_INTERFACE.md"):
        if not (ROOT / required).is_file():
            errors.append(f"Missing project file: {required}")
    if errors:
        print("\n".join(f"ERROR: {error}" for error in errors), file=sys.stderr)
        return 1

    print(f"Static structure checks passed for {len(PROGRAMS)} GLSL program pairs and shadow.")
    print("Checks include file pairing, entry points, include resolution, and fragment varying names.")
    print("This check does not parse, compile, or link GLSL in Iris.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
