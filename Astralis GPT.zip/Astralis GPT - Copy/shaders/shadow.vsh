#version 120

#include "/lib/shadow_config.glsl"

varying vec2 vTexCoord;
varying vec4 vVertexColor;

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vVertexColor = gl_Color;
}

