#version 120

uniform float sunAngle;
uniform float rainStrength;

varying vec4 vColor;

void main() {
    float solarElevation = sin(sunAngle * 6.2831853);
    float twilight = 1.0 - smoothstep(0.015, 0.45, abs(solarElevation));
    float night = 1.0 - smoothstep(-0.12, 0.12, solarElevation);
    vec3 sunsetTint = mix(vec3(1.10, 0.80, 0.76),
                          vec3(1.08, 0.91, 1.16),
                          smoothstep(0.0, 0.25, solarElevation));
    vec3 sky = mix(vColor.rgb, vColor.rgb * sunsetTint, twilight * 0.48);
    vec3 moonlitTint = mix(vec3(1.0), vec3(0.78, 0.84, 1.12), night * 0.46);
    sky *= moonlitTint;
    float luminance = dot(sky, vec3(0.299, 0.587, 0.114));
    sky = mix(sky, vec3(luminance), rainStrength * 0.12);
    gl_FragColor = vec4(sky, vColor.a);
}
