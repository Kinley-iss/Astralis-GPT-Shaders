#version 120

#include "/lib/shadow_config.glsl"

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform vec3 shadowLightPosition;
uniform vec3 endFlashPosition;
uniform float endFlashIntensity;
uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;
uniform float rainStrength;
uniform float sunAngle;
uniform int isEyeInWater;

varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec4 vVertexColor;
varying vec3 vViewPosition;
varying vec3 vViewNormal;
varying vec4 vShadowPosition;

#include "/lib/lighting.glsl"

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vVertexColor;
    vec3 lightmapColor = texture2D(lightmap, vLightCoord).rgb;
    lightmapColor = astralisVibrantBlockLight(lightmapColor, vLightCoord.x);
    vec3 normal = astralisSafeNormalize(vViewNormal, vec3(0.0, 0.0, 1.0));
    vec3 lightDirection = astralisSafeNormalize(shadowLightPosition, vec3(0.0, 1.0, 0.0));
    float directLight = max(dot(normal, lightDirection), 0.0);
    float shadow = astralisShadowVisibility(vShadowPosition, vViewPosition, normal, lightDirection);
    float skyAmount = clamp(vLightCoord.y * 1.5, 0.0, 1.0);
    vec3 illumination = astralisCelestialIllumination(lightmapColor, directLight, shadow,
                                                      skyAmount, normal, vViewPosition);

    float greenFoliage = step(albedo.r * 1.15, albedo.g) * step(albedo.b * 1.10, albedo.g);
    float backLight = max(dot(-normal, lightDirection), 0.0) * shadow;
    vec3 color = albedo.rgb * illumination;
    color += albedo.rgb * vec3(0.075, 0.095, 0.055) * greenFoliage * backLight;
    
    float solarElevation = sin(sunAngle * 6.2831853);
    color = astralisAtmosphericGrade(color, solarElevation, rainStrength);
    color = astralisUnderwaterFilter(color, isEyeInWater);
    color = astralisApplyFog(color, vViewPosition);
    gl_FragColor = vec4(color, albedo.a);
}
