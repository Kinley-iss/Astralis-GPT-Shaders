const float ASTRALIS_MIN_LIGHT = 0.06;
const float ASTRALIS_MAX_LIGHT = 1.0;

vec3 astralisBoundLight(vec3 light) {
    return clamp(light, vec3(ASTRALIS_MIN_LIGHT), vec3(ASTRALIS_MAX_LIGHT));
}
