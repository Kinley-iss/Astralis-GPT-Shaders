#define SHADOW_QUALITY 4 // [1 4 9] Shadow comparison taps
#define SHADOW_PIXEL_SIZE 4 // [1 2 4 8] Shadow map texels per hard shadow pixel

const int shadowMapResolution = 1024;
const float shadowDistance = 80.0;
