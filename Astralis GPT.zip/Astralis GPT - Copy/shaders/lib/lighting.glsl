#define FOG_DENSITY_SCALE 1.0 // [0.75 1.0 1.15] Fog amount multiplier

#include "/lib/light_bounds.glsl"

vec3 astralisSafeNormalize(vec3 value, vec3 fallback) {
    float magnitudeSquared = dot(value, value);
    if (magnitudeSquared > 0.0000001) {
        return value * inversesqrt(magnitudeSquared);
    }
    return fallback;
}

float astralisShadowCompare(vec3 shadowPosition, float bias, float texel, vec2 offset) {
    float depth = texture2D(shadowtex0, shadowPosition.xy + offset * texel).r;
    return shadowPosition.z - bias <= depth ? 1.0 : 0.0;
}

float astralisShadowVisibility(vec4 shadowClip, vec3 viewPosition, vec3 normalView, vec3 lightDirection) {
    if (shadowClip.w <= 0.0) {
        return 1.0;
    }

    vec3 shadowPosition = shadowClip.xyz / shadowClip.w;
    shadowPosition = shadowPosition * 0.5 + 0.5;

    if (shadowPosition.x <= 0.001 || shadowPosition.x >= 0.999 ||
        shadowPosition.y <= 0.001 || shadowPosition.y >= 0.999 ||
        shadowPosition.z <= 0.0 || shadowPosition.z >= 1.0) {
        return 1.0;
    }

#if SHADOW_PIXEL_SIZE > 1
    float pixelStep = float(SHADOW_PIXEL_SIZE) / float(shadowMapResolution);
    shadowPosition.xy = (floor(shadowPosition.xy / pixelStep) + vec2(0.5)) * pixelStep;
    shadowPosition.xy = clamp(shadowPosition.xy, vec2(pixelStep * 0.5),
                              vec2(1.0 - pixelStep * 0.5));
#endif

    float facing = max(dot(astralisSafeNormalize(normalView, vec3(0.0, 0.0, 1.0)),
                           astralisSafeNormalize(lightDirection, vec3(0.0, 1.0, 0.0))), 0.0);
    float bias = mix(0.0015, 0.00045, facing);
    float texel = 1.0 / float(shadowMapResolution);
    float visibility = 0.0;

#if SHADOW_PIXEL_SIZE > 1
    visibility = astralisShadowCompare(shadowPosition, bias, texel, vec2(0.0));
#elif SHADOW_QUALITY == 1
    visibility = astralisShadowCompare(shadowPosition, bias, texel, vec2(0.0));
#elif SHADOW_QUALITY == 4
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2(-0.5, -0.5));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 0.5, -0.5));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2(-0.5,  0.5));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 0.5,  0.5));
#else
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2(-1.0, -1.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 0.0, -1.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 1.0, -1.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2(-1.0,  0.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 0.0,  0.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 1.0,  0.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2(-1.0,  1.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 0.0,  1.0));
    visibility += astralisShadowCompare(shadowPosition, bias, texel, vec2( 1.0,  1.0));
#endif
#if SHADOW_PIXEL_SIZE == 1
    visibility /= float(SHADOW_QUALITY);
#endif

    float edgeFade = clamp(min(min(shadowPosition.x, 1.0 - shadowPosition.x),
                               min(shadowPosition.y, 1.0 - shadowPosition.y)) * 12.0, 0.0, 1.0);
    float distanceFade = clamp((1.0 - length(viewPosition) / shadowDistance) * 5.0, 0.0, 1.0);
    float fade = min(edgeFade, distanceFade);
    return mix(1.0, visibility, fade);
}

float astralisFogFactor(vec3 viewPosition) {
    float fogRange = max(fogEnd - fogStart, 0.001);
    return clamp((length(viewPosition) - fogStart) / fogRange * FOG_DENSITY_SCALE, 0.0, 1.0);
}

vec3 astralisApplyFog(vec3 color, vec3 viewPosition) {
    return mix(color, fogColor, astralisFogFactor(viewPosition));
}

vec3 astralisVibrantBlockLight(vec3 lightColor, float blockLightCoordinate) {
    float emission = smoothstep(0.025, 0.82, clamp(blockLightCoordinate, 0.0, 1.0));
    return lightColor * (1.0 + emission * 0.65);
}

float astralisDaylightFactor() {
    float solarElevation = sin(sunAngle * 6.2831853);
    return smoothstep(-0.12, 0.12, solarElevation);
}

vec3 astralisCelestialIllumination(vec3 lightmapColor, float directLight, float shadow,
                                   float skyAmount, vec3 normal, vec3 viewPosition) {
    float solarElevation = sin(sunAngle * 6.2831853);
    float daylight = smoothstep(-0.12, 0.12, solarElevation);
    float twilight = 1.0 - smoothstep(0.0, 0.5, abs(solarElevation));

    vec3 sunColor = mix(vec3(1.0, 0.94, 0.82), vec3(1.0, 0.99, 0.95),
                        smoothstep(0.05, 0.9, daylight));
    sunColor = mix(sunColor, vec3(1.0, 0.68, 0.43), twilight * 0.55);
    vec3 moonColor = vec3(0.48, 0.60, 0.86);
    vec3 celestialColor = mix(moonColor, sunColor, daylight);

    float cloudSoftening = clamp(rainStrength * 0.45, 0.0, 0.45);
    float directionalVisibility = mix(shadow, 1.0, cloudSoftening);
    float directTerm = clamp(directLight, 0.0, 1.0) * directionalVisibility;
    float directContribution = clamp(directTerm * skyAmount, 0.0, 1.0);
    float ambientFill = mix(0.78, 0.54, skyAmount);
    vec3 illumination = lightmapColor
                      * (ambientFill + (1.0 - ambientFill) * directContribution);
    float moonContribution = (1.0 - daylight) * 0.12;
    float sunContribution = daylight * mix(0.12, 1.0, daylight);
    illumination += celestialColor * directContribution
                    * (sunContribution + moonContribution) * 0.18;

    vec3 flashDirection = astralisSafeNormalize(endFlashPosition - viewPosition,
                                                vec3(0.0, 0.0, 1.0));
    float flashDiffuse = max(dot(normal, flashDirection), 0.0);
    float flashIntensity = clamp(endFlashIntensity, 0.0, 1.0);
    illumination += vec3(0.78, 0.86, 1.0) * flashIntensity
                    * mix(0.22, 1.0, flashDiffuse) * 0.42;
    return astralisBoundLight(illumination);
}

vec3 astralisWarmDaylight(vec3 color, float lightAmount) {
    float sunset = pow(abs(cos(sunAngle * 6.2831853)), 5.0);
    vec3 warm = color * vec3(1.045, 1.005, 0.955);
    vec3 daylight = mix(color, warm, sunset * 0.32 * lightAmount);
    vec3 rainy = vec3(dot(daylight, vec3(0.299, 0.587, 0.114)));
    return mix(daylight, rainy, clamp(rainStrength * 0.16, 0.0, 0.16));
}

vec3 astralisAtmosphericGrade(vec3 color, float sunElevation, float rainStrength) {
    float twilight = 1.0 - smoothstep(0.0, 0.5, abs(sunElevation));
    float daylight = smoothstep(-0.12, 0.12, sunElevation);
    float nightFactor = 1.0 - daylight;
    
    vec3 twilightGrade = color;
    twilightGrade *= mix(vec3(1.0), vec3(1.12, 0.94, 1.08), twilight * 0.35);
    
    vec3 nightGrade = color * vec3(0.84, 0.91, 1.12);
    nightGrade *= mix(1.0, 0.90, nightFactor);
    
    vec3 graded = mix(color, twilightGrade, twilight * 0.35);
    graded = mix(graded, nightGrade, nightFactor * 0.72);
    
    float rainDim = mix(1.0, 0.92, rainStrength * 0.25);
    graded *= rainDim;
    
    return graded;
}

vec3 astralisUnderwaterFilter(vec3 color, int eyeInWater) {
    if (eyeInWater == 0) {
        return color;
    }
    vec3 underwaterTint = vec3(0.58, 0.84, 1.16);
    color *= mix(vec3(1.0), underwaterTint, 0.62);
    return color;
}
