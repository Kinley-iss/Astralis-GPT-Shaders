#version 120

#include "/lib/shadow_config.glsl"

#define WATER_REFLECTION // Pixelated analytic-sky reflection
#define WATER_PIXEL_SIZE 12 // [4 8 12 16 24] Screen pixels per reflection cell

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex0;
uniform vec3 shadowLightPosition;
uniform vec3 endFlashPosition;
uniform float endFlashIntensity;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float fogStart;
uniform float fogEnd;
uniform float rainStrength;
uniform float sunAngle;
uniform int isEyeInWater;

varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec4 vVertexColor;
varying vec3 vViewPosition;
varying vec3 vViewNormal;
varying vec4 vShadowPosition;

#include "/lib/lighting.glsl"

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vVertexColor;
    vec3 normal = astralisSafeNormalize(vViewNormal, vec3(0.0, 0.0, 1.0));
    vec3 lightDirection = astralisSafeNormalize(shadowLightPosition, vec3(0.0, 1.0, 0.0));
    float skyAmount = clamp(vLightCoord.y * 1.5, 0.0, 1.0);
    float directLight = max(dot(normal, lightDirection), 0.0);
    float shadow = astralisShadowVisibility(vShadowPosition, vViewPosition, normal, lightDirection);
    vec3 lightmapColor = texture2D(lightmap, vLightCoord).rgb;
    lightmapColor = astralisVibrantBlockLight(lightmapColor, vLightCoord.x);
    vec3 illumination = astralisCelestialIllumination(lightmapColor, directLight, shadow,
                                                      skyAmount, normal, vViewPosition);
    vec3 baseWater = albedo.rgb * illumination * vec3(0.90, 1.015, 1.045);

    vec3 color = baseWater;
#ifdef WATER_REFLECTION
    vec2 cell = floor(gl_FragCoord.xy / float(WATER_PIXEL_SIZE));
    vec2 cellCenter = (cell + vec2(0.5)) * float(WATER_PIXEL_SIZE);
    vec2 cellOffset = cellCenter - gl_FragCoord.xy;
    vec3 cellViewPosition = vViewPosition
                          + dFdx(vViewPosition) * cellOffset.x
                          + dFdy(vViewPosition) * cellOffset.y;
    vec3 cellNormal = astralisSafeNormalize(
        vViewNormal + dFdx(vViewNormal) * cellOffset.x
                    + dFdy(vViewNormal) * cellOffset.y,
        normal);
    vec3 viewDirection = astralisSafeNormalize(-cellViewPosition,
                                                vec3(0.0, 0.0, 1.0));
    vec3 reflectedDirection = reflect(-viewDirection, cellNormal);
    float skyBlend = smoothstep(-0.18, 0.55, reflectedDirection.y);
    vec3 reflectedSky = mix(fogColor, skyColor, skyBlend);

    float reflectionSolarElevation = sin(sunAngle * 6.2831853);
    float twilight = 1.0 - smoothstep(0.015, 0.45, abs(reflectionSolarElevation));
    vec3 twilightSkyTint = mix(vec3(1.08, 0.80, 0.84),
                               vec3(0.86, 0.88, 1.16),
                               smoothstep(0.0, 0.25, reflectionSolarElevation));
    float horizonBlend = 1.0 - smoothstep(0.0, 0.45, abs(reflectedDirection.y));
    reflectedSky *= mix(vec3(1.0), twilightSkyTint, twilight * horizonBlend * 0.42);

    vec3 sunColor = mix(vec3(1.0, 0.78, 0.48), vec3(1.0, 0.96, 0.82),
                        smoothstep(0.05, 0.45, astralisDaylightFactor()));
    float sunAlignment = max(dot(reflectedDirection, lightDirection), 0.0);
    float reflectedSun = pow(sunAlignment, 256.0)
                       * astralisDaylightFactor() * skyAmount;
    reflectedSky += sunColor * reflectedSun * 1.5;

    float fresnel = 0.02 + 0.98 * pow(
        1.0 - max(dot(cellNormal, viewDirection), 0.0), 5.0);
    float reflectionStrength = clamp(0.12 + fresnel * 0.72, 0.0, 0.84) * skyAmount;
    color = mix(baseWater, reflectedSky, reflectionStrength);
#endif
    float solarElevation = sin(sunAngle * 6.2831853);
    color = astralisAtmosphericGrade(color, solarElevation, rainStrength);
    color = astralisUnderwaterFilter(color, isEyeInWater);
    color = astralisApplyFog(color, vViewPosition);
    gl_FragColor = vec4(color, albedo.a);
}
