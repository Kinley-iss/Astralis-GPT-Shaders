#version 120

uniform sampler2D texture;
uniform sampler2D lightmap;

#include "/lib/light_bounds.glsl"

varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec4 vVertexColor;

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vVertexColor;
    vec3 light = texture2D(lightmap, vLightCoord).rgb;
    float emission = smoothstep(0.025, 0.82, clamp(vLightCoord.x, 0.0, 1.0));
    light *= 1.0 + emission * 0.65;
    light = astralisBoundLight(light);
    gl_FragColor = vec4(albedo.rgb * light, albedo.a);
}
