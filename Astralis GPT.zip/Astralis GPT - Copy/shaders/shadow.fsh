#version 120

uniform sampler2D texture;
uniform float alphaTestRef;

varying vec2 vTexCoord;
varying vec4 vVertexColor;

void main() {
    float alpha = texture2D(texture, vTexCoord).a * vVertexColor.a;
    if (alpha < alphaTestRef) {
        discard;
    }
    gl_FragColor = vec4(1.0);
}

