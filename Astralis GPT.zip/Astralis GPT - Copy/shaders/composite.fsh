#version 120

#define BLOOM 1 // [0 1] Thresholded four-tap bloom
#define BLOOM_STRENGTH 0.045 // [0.00 0.025 0.045 0.07] Bloom intensity
#define AO_QUALITY 4 // [0 4 8] Screen-space contact occlusion taps
#define SUNRAY_QUALITY 4 // [0 4 8] Screen-space sunlight shaft taps
#define SUNRAY_STRENGTH 0.16 // [0.00 0.10 0.16 0.24] Sunlight shaft intensity
#define SCREEN_TRACE_STEPS 0 // [0 8 12] Screen-space reflection/path ray steps
#define PATH_TRACE_STRENGTH 0.00 // [0.00 0.04 0.08] One-bounce screen-space diffuse lighting

/* RENDERTARGETS: 3 */

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float sunAngle;
uniform float rainStrength;

varying vec2 vTexCoord;

float astralisViewDepth(vec2 uv) {
    float depth = texture2D(depthtex0, uv).r;
    if (depth >= 0.999999) {
        return -1.0;
    }

    vec4 clipPosition = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewPosition = gbufferProjectionInverse * clipPosition;
    if (abs(viewPosition.w) < 0.000001) {
        return -1.0;
    }
    return -viewPosition.z / viewPosition.w;
}

float astralisDepthOcclusion(float centerDepth, float sampleDepth) {
    if (sampleDepth < 0.0) {
        return 0.0;
    }
    return smoothstep(0.025, 0.20, centerDepth - sampleDepth);
}

float highlightWeight(vec3 color) {
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    return clamp((luminance - 0.72) / max(luminance, 0.001), 0.0, 1.0);
}

float astralisSunShaftSample(vec2 uv, out vec3 color) {
    float depth = texture2D(depthtex0, uv).r;
    color = texture2D(colortex0, uv).rgb;
    if (depth < 0.99999) {
        return 0.0;
    }
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    return smoothstep(0.48, 0.92, luminance);
}

vec3 astralisReconstructViewPosition(vec2 uv, float depth) {
    vec4 clipPosition = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewPosition = gbufferProjectionInverse * clipPosition;
    float safeW = abs(viewPosition.w) > 0.000001 ? viewPosition.w : 0.000001;
    return viewPosition.xyz / safeW;
}

#if SCREEN_TRACE_STEPS > 0
bool astralisTraceScreenRay(vec3 origin, vec3 direction, out vec2 hitUv) {
    float stride = max(0.12, -origin.z * 0.035);
    for (int stepIndex = 1; stepIndex <= SCREEN_TRACE_STEPS; ++stepIndex) {
        vec3 rayPosition = origin + direction * stride * float(stepIndex);
        if (rayPosition.z >= -0.05) {
            break;
        }

        vec4 clipPosition = gbufferProjection * vec4(rayPosition, 1.0);
        if (clipPosition.w <= 0.0001) {
            break;
        }
        vec2 uv = clipPosition.xy / clipPosition.w * 0.5 + 0.5;
        if (uv.x <= 0.001 || uv.x >= 0.999 || uv.y <= 0.001 || uv.y >= 0.999) {
            break;
        }

        float sceneDepth = texture2D(depthtex1, uv).r;
        if (sceneDepth < 0.999999) {
            vec3 scenePosition = astralisReconstructViewPosition(uv, sceneDepth);
            float depthDifference = -rayPosition.z + scenePosition.z;
            float thickness = max(0.08, -rayPosition.z * 0.012);
            if (depthDifference >= 0.0 && depthDifference < thickness &&
                stepIndex > 1) {
                hitUv = uv;
                return true;
            }
        }
    }
    hitUv = vec2(0.0);
    return false;
}
#endif

void main() {
    vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));
    vec3 scene = texture2D(colortex0, vTexCoord).rgb;
#if SCREEN_TRACE_STEPS > 0
    float translucentDepth = texture2D(depthtex0, vTexCoord).r;
    float opaqueDepth = texture2D(depthtex1, vTexCoord).r;
    if (translucentDepth < 0.999999) {
        vec3 surfacePosition = astralisReconstructViewPosition(vTexCoord, translucentDepth);
        vec3 positionDx = dFdx(surfacePosition);
        vec3 positionDy = dFdy(surfacePosition);
        vec3 surfaceNormal = normalize(cross(positionDx, positionDy));
        vec3 viewDirection = normalize(-surfacePosition);
        if (dot(surfaceNormal, viewDirection) < 0.0) {
            surfaceNormal = -surfaceNormal;
        }

        float opaqueLinearDepth = opaqueDepth < 0.999999
                                ? -astralisReconstructViewPosition(vTexCoord, opaqueDepth).z
                                : -1.0;
        float translucentLinearDepth = -surfacePosition.z;
        float waterMask = opaqueLinearDepth > 0.0
                        ? smoothstep(0.08, 0.35,
                                     opaqueLinearDepth - translucentLinearDepth)
                        : 0.0;
        if (waterMask > 0.0) {
            vec3 reflectionDirection = reflect(-viewDirection, surfaceNormal);
            vec2 reflectionUv;
            if (astralisTraceScreenRay(surfacePosition + surfaceNormal * 0.04,
                                       reflectionDirection, reflectionUv)) {
                float fresnel = 0.02 + 0.72
                              * pow(1.0 - max(dot(surfaceNormal, viewDirection), 0.0), 5.0);
                vec3 reflectedScene = texture2D(colortex0, reflectionUv).rgb;
                scene = mix(scene, reflectedScene, waterMask * fresnel);
            }
        }
    }

    if (PATH_TRACE_STRENGTH > 0.0 && opaqueDepth < 0.999999) {
        vec3 surfacePosition = astralisReconstructViewPosition(vTexCoord, opaqueDepth);
        vec3 positionDx = dFdx(surfacePosition);
        vec3 positionDy = dFdy(surfacePosition);
        vec3 surfaceNormal = normalize(cross(positionDx, positionDy));
        vec3 viewDirection = normalize(-surfacePosition);
        if (dot(surfaceNormal, viewDirection) < 0.0) {
            surfaceNormal = -surfaceNormal;
        }

        vec3 tangent = normalize(cross(surfaceNormal,
            abs(surfaceNormal.z) < 0.9 ? vec3(0.0, 0.0, 1.0)
                                       : vec3(0.0, 1.0, 0.0)));
        vec3 bitangent = cross(surfaceNormal, tangent);
        float noise = fract(sin(dot(floor(gl_FragCoord.xy),
                                    vec2(12.9898, 78.233))) * 43758.5453);
        vec3 bouncedLight = vec3(0.0);
        float bounceSamples = 0.0;

        for (int sampleIndex = 0; sampleIndex < 2; ++sampleIndex) {
            float angle = noise * 6.2831853 + float(sampleIndex) * 3.1415927;
            vec3 rayDirection = normalize(surfaceNormal
                + tangent * cos(angle) * 0.7
                + bitangent * sin(angle) * 0.7);
            vec2 bounceUv;
            if (astralisTraceScreenRay(surfacePosition + surfaceNormal * 0.04,
                                       rayDirection, bounceUv)) {
                bouncedLight += texture2D(colortex0, bounceUv).rgb;
                bounceSamples += 1.0;
            }
        }
        if (bounceSamples > 0.0) {
            scene += bouncedLight / bounceSamples * PATH_TRACE_STRENGTH * 0.25;
        }
    }
#endif
#if AO_QUALITY > 0
    float centerDepth = astralisViewDepth(vTexCoord);
    if (centerDepth > 0.0) {
        float occlusion = 0.0;
        float tapCount = 0.0;
        vec2 radius = texel * 2.0;
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2( radius.x, 0.0)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2(-radius.x, 0.0)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2(0.0,  radius.y)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2(0.0, -radius.y)));
        tapCount += 4.0;
#if AO_QUALITY > 4
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2( radius.x,  radius.y)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2(-radius.x,  radius.y)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2( radius.x, -radius.y)));
        occlusion += astralisDepthOcclusion(centerDepth, astralisViewDepth(vTexCoord + vec2(-radius.x, -radius.y)));
        tapCount += 4.0;
#endif
        float ao = 1.0 - (occlusion / tapCount) * 0.20;
        scene *= clamp(ao, 0.78, 1.0);
    }
#endif
#if SUNRAY_QUALITY > 0
    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    if (sunClip.w > 0.0001) {
        vec2 sunUv = sunClip.xy / sunClip.w * 0.5 + 0.5;
        if (sunUv.x >= 0.0 && sunUv.x <= 1.0 &&
            sunUv.y >= 0.0 && sunUv.y <= 1.0) {
            vec2 rayStep = (sunUv - vTexCoord) / float(SUNRAY_QUALITY + 1);
            vec3 shafts = vec3(0.0);
            float shaftWeight = 0.0;
            vec3 sampleColor;
            float sampleWeight;

            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 2.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 3.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 4.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
#if SUNRAY_QUALITY > 4
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 5.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 6.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 7.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
            sampleWeight = astralisSunShaftSample(vTexCoord + rayStep * 8.0, sampleColor);
            shafts += sampleColor * sampleWeight;
            shaftWeight += sampleWeight;
#endif
            float solarElevation = sin(sunAngle * 6.2831853);
            float daylight = smoothstep(-0.08, 0.16, solarElevation);
            float twilight = 1.0 - smoothstep(0.03, 0.5, abs(solarElevation));
            vec3 shaftTint = mix(vec3(1.0, 0.76, 0.52),
                                 vec3(1.0, 0.95, 0.84),
                                 smoothstep(0.12, 0.75, solarElevation));
            shaftTint = mix(vec3(0.55, 0.68, 0.92), shaftTint, daylight);
            float shaftIntensity = SUNRAY_STRENGTH * daylight
                                 * (1.0 - rainStrength * 0.75);
            shaftIntensity *= mix(1.0, 1.18, twilight);
            scene += shafts / max(float(SUNRAY_QUALITY), 1.0)
                   * shaftTint * shaftIntensity;
        }
    }
#endif
#if BLOOM
    vec3 bloom = vec3(0.0);
    bloom += texture2D(colortex0, vTexCoord + vec2( texel.x * 2.0, 0.0)).rgb;
    bloom += texture2D(colortex0, vTexCoord + vec2(-texel.x * 2.0, 0.0)).rgb;
    bloom += texture2D(colortex0, vTexCoord + vec2(0.0,  texel.y * 2.0)).rgb;
    bloom += texture2D(colortex0, vTexCoord + vec2(0.0, -texel.y * 2.0)).rgb;
    bloom *= 0.25;
    bloom *= highlightWeight(bloom);
    scene += bloom * BLOOM_STRENGTH;
#endif
    gl_FragData[0] = vec4(scene, 1.0);
}
