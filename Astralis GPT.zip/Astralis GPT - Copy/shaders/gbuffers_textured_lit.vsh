#version 120

varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec4 vVertexColor;

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    vVertexColor = gl_Color;
}

