#version 120

uniform sampler2D texture;
uniform float sunAngle;

varying vec2 vTexCoord;
varying vec4 vVertexColor;

void main() {
    vec4 celestial = texture2D(texture, vTexCoord) * vVertexColor;
    float daylight = smoothstep(-0.12, 0.12, sin(sunAngle * 6.2831853));
    vec3 sunTint = mix(vec3(1.0, 0.82, 0.62), vec3(1.0, 0.96, 0.84),
                       smoothstep(0.05, 0.85, daylight));
    vec3 moonTint = vec3(0.78, 0.86, 1.0);
    vec3 celestialTint = mix(moonTint, sunTint, daylight);
    float diskLuminance = dot(celestial.rgb, vec3(0.299, 0.587, 0.114));
    float diskCore = smoothstep(0.45, 0.95, diskLuminance) * celestial.a;
    vec3 color = celestial.rgb * celestialTint * mix(1.25, 1.55, daylight);
    color += sunTint * diskCore * daylight * 0.45;
    gl_FragColor = vec4(color, celestial.a);
}
