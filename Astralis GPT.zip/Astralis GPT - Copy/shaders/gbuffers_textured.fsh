#version 120

uniform sampler2D texture;

varying vec2 vTexCoord;
varying vec4 vVertexColor;

void main() {
    vec4 albedo = texture2D(texture, vTexCoord) * vVertexColor;
    gl_FragColor = albedo;
}
