#version 120

varying vec2 vTexCoord;
varying vec2 vLightCoord;
varying vec4 vVertexColor;
varying vec3 vViewPosition;
varying vec3 vViewNormal;
varying vec4 vShadowPosition;

uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

void main() {
    gl_Position = ftransform();
    vTexCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vLightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    vVertexColor = gl_Color;
    vec4 viewPosition = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPosition = gbufferModelViewInverse * viewPosition;
    vViewPosition = viewPosition.xyz;
    vViewNormal = gl_NormalMatrix * gl_Normal;
    vShadowPosition = shadowProjection * shadowModelView * playerPosition;
}
