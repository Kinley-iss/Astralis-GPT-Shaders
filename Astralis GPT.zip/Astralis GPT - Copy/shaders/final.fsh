#version 120

uniform sampler2D colortex3;

varying vec2 vTexCoord;

void main() {
    vec3 color = texture2D(colortex3, vTexCoord).rgb;
    
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    
    float saturation = 1.16;
    color = mix(vec3(luminance), color, saturation);
    
    float contrast = 1.025;
    float brightnessShift = 0.5;
    color = (color - brightnessShift) * contrast + brightnessShift;
    
    float vibrance = mix(1.0, 1.14, smoothstep(0.2, 0.8, luminance));
    color = mix(vec3(luminance), color, vibrance);
    
    gl_FragColor = clamp(vec4(color, 1.0), 0.0, 1.0);
}
