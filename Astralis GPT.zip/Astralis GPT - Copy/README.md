# Astralis GPT

Astralis GPT is an experimental Iris shader pack for Minecraft Java, aiming at the
color, atmosphere, and lighting character of Bedrock's Vibrant Visuals (VV). It is
an approximation built on Java's Iris/OpenGL pipeline, not a port of Bedrock's
renderer or a verified visual match.

## Status

| Evidence level | Status |
| --- | --- |
| L0 — Written | Pack source and a manual test protocol are present. |
| L1 — Static | Structure/include/varying checks and ZIP checks pass (see `docs\TEST_LOG.md`). These do not replace a GLSL compiler. |
| L2 — Iris compile/link | NOT VERIFIED — Minecraft and Iris have not been launched with this pack. |
| L3 — In-game appearance | NOT VERIFIED. |
| L4 — Performance | NOT VERIFIED; no FPS or frame-time results are claimed. |

Read-only inspection found a local Minecraft 26.3 / Iris 1.11.7 / Sodium 0.9.2
installation and Fabric Loader 0.19.5. The pack has not been loaded in that install.
The detected graphics adapter is Vega 3, not the brief's Vega 8 target.

## Installation (unverified)

Place the `Astralis GPT` folder or built ZIP in the Minecraft `shaderpacks` directory,
then select it from Iris's shader-pack menu. Use Minecraft's OpenGL renderer; Iris
does not render shader packs through the Vulkan backend. Exact menu labels and
compatibility with Minecraft 26.3 must be confirmed on the target installation.

## What Vibrant Visuals includes

Microsoft's Bedrock creator documentation describes orbital sun/moon lighting,
End flashes, ambient and sky contributions, block-local light sources, emissive
desaturation, Rayleigh/Mie atmospheric scattering, biome-specific blended visuals,
water appearance/waves/caustics, and per-channel color grading and tone mapping.
See the official [lighting](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/lightingcustomization?view=minecraft-bedrock-stable),
[atmospherics](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/atmosphericscustomization?view=minecraft-bedrock-stable),
[water](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/watercustomization?view=minecraft-bedrock-stable),
[color grading](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/colorgradingtonemappingcustomization?view=minecraft-bedrock-stable),
and [biome customization](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/biomecustomization?view=minecraft-bedrock-stable)
docs. Astralis GPT only approximates a subset through Iris; it does not reproduce
Bedrock's data-driven renderer.

## What is in this build

- An Iris-configured shadow depth map with profile-controlled resolution/distance,
  pixel-stepped filtering, and stronger normal-aware direct-sun contrast for terrain,
  entities, and water, plus Iris-driven sun/moon and End-flash lighting. The GPU computes
  per-fragment directional incidence and shadow-map visibility; block/entity illumination
  is kept within a small 0.06 floor and 1.0 upper bound. This is not multi-bounce path
  tracing. In-game shadow coverage and orientation still need confirmation.
- Existing vanilla lightmap and vertex tint/AO, with sun/moon and twilight color-tinting,
  a brighter warm daytime sun sprite, a cool blue moonlit night grade that preserves scene
  color, rain dampening, and a
  green-foliage backlight approximation.
- Block/point lighting brightened by up to 65% based on vanilla block-lightmap intensity,
  preserving the lightmap's existing color. Exact Bedrock per-block RGB matching is not
  possible here because the Java pass does not expose the identity of nearby light blocks.
- Underwater cyan-tint filter driven by Iris's integer `isEyeInWater` uniform.
- Iris `entityColor` tint applied after lighting and fog in the entity pass, preserving
  vanilla red damage flashes and other entity overlays.
- Distance fog using Iris's biome/weather-aware vanilla fog range and color.
- Screen-space sun shafts sampled from bright sky pixels to approximate the light beams
  through foliage shown in the local Vibrant Visuals reference video. This is not a
  volumetric or temporally accumulated light simulation; quality and strength are configurable.
- Water Fresnel plus a screen-pixelated analytic sky/horizon reflection. View position and
  normal are interpolated to each configurable screen-cell center, then the reflected ray
  selects the sky/horizon blend and aligns the sun disk with Iris's active light direction.
  This avoids the former tile-center-based artificial glints. Reflection-cell size is
  configurable in the Water & Reflections menu. Quality additionally blends screen-space
  opaque-scene hits in the composite pass; the analytic sky reflection remains the fallback
  when a screen ray misses. Depth-derived hits and appearance need in-game verification.
- Thresholded four-direction bloom and a stronger final saturation/vibrance grade that
  preserves color in darker scenes, with a subtle contrast adjustment.
- Quality-only screen-space ray marching for reflected opaque scene color on water,
  plus two diffuse screen rays for a restrained one-bounce indirect-light approximation.
  The trace can only hit visible depth/color-buffer geometry; it is not full scene
  ray tracing or path tracing and cannot see off-screen or occluded surfaces.
- Performance/Balanced/Quality profiles that change shadow map resolution, shadow distance,
  shadow pixel size/filter taps, contact-occlusion taps, fog scaling, water reflections,
  and bloom.
- Vanilla sky/sun/moon/cloud textures are retained; the sky gets a subtle low-sun tint
  and the dedicated sun/moon texture pass boosts celestial brightness and warmth.

Balanced is the default profile. Performance uses a 256-pixel shadow map and 32-block
shadow distance, and compiles out contact occlusion, sun shafts, water reflections,
and bloom. Quality uses a 2048-pixel shadow map and 112-block distance, enables the
soft 9-tap shadow filter, and enables the screen-space ray/reflection and one-bounce
indirect-light approximation. FPS gains have not been measured. Switch profiles from
Minecraft's Options → Video Settings → Shader Packs →
Astralis GPT settings; Iris does not provide a default keyboard shortcut for profiles.

The local reference video emphasizes broad, soft color, bright low-angle sun over water,
deep blue underwater scenes, dramatic shafts through cave foliage, and warm point lights
at night. Astralis GPT now leans toward those elements, but cannot reproduce Bedrock's
RenderDragon lighting, material data, temporal effects, or exact scene-specific output in
an Iris shader pack.

The feature matrix lists significant gaps. Screen-space refraction,
volumetric shafts, dynamic procedural clouds, material/PBR tables, reliable emissive
extraction, colored glass shadows, complete biome-specific interpolation, and
dimension-specific grading are not implemented in this build.

See [docs/JAVA_26_3_VV_MAPPING.md](docs/JAVA_26_3_VV_MAPPING.md) for the mapping
from Bedrock Vibrant Visuals concepts to the Java 26.3/Iris effects and limitations.

## Validation

`tools\check_all.py` checks source pairing, entry points, includes, varying interfaces,
and that settings are wired to code, labels, and profiles; it is not a GLSL compiler
and does not establish that Iris accepts the pack.
See `docs\MANUAL_TEST_PROTOCOL.md` for runtime verification steps and evidence to
collect.
