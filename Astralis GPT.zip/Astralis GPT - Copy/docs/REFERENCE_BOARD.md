# Reference board

Retrieved 2026-10-11. References are primary-source descriptions, not a visual
Bedrock-vs-Java screenshot comparison.

## Microsoft Learn: Bedrock Vibrant Visuals light sources

URL: https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/lightingcustomization?view=minecraft-bedrock-stable

The official creator documentation describes separate directional orbital lights
(sun and moon), End flashes, emissive-light desaturation, fallback ambient light,
sky contribution to diffuse/specular lighting, and local block-light colors. It
states example real-world illuminance levels of 100,000+ lux for noon sun and less
than one lux for moonlight. Its ambient fallback range is 0–5 lux with a documented
default of 0.02 lux; sky intensity is controlled separately. Biome-specific global
lighting can vary. The pack cannot reproduce these physical settings exactly from
Java's lightmap and currently uses relative approximations.

## Microsoft Learn: atmosphere, water, grading, and biomes

- [Atmospheric Effects](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/atmosphericscustomization?view=minecraft-bedrock-stable)
  describes horizon blend stops, Rayleigh strength, sun/moon Mie scattering,
  sun-glare shape, and keyframed zenith/horizon colors.
- [Water Effects](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/watercustomization?view=minecraft-bedrock-stable)
  describes absorption/color influenced by CDOM, chlorophyll, and suspended sediment;
  optional image-based waves that do not move the water vertices; and underwater
  caustics.
- [Color Grading and Tone Mapping](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/colorgradingtonemappingcustomization?view=minecraft-bedrock-stable)
  documents per-channel saturation, contrast, gain, gamma, and offset, with separate
  shadow/midtone/highlight grading controls.
- [Biome Customization](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/biomecustomization?view=minecraft-bedrock-stable)
  describes spatially blended atmosphere, lighting, color grading, and cubemaps,
  plus water settings blended per-geometry location.

These sources were retrieved 2026-10-11. Astralis GPT currently lacks the Bedrock
data-driven schemas, full atmospheric scattering, water absorption/waves/caustics,
per-channel grading, and smooth biome-settings interpolation.

## Iris DocsPage current interface

URL: https://github.com/IrisShaders/DocsPage/tree/main/src/content/docs/current

Specific program, uniform, buffer, attribute, constant, coordinate-space and include
pages are linked in [IRIS_INTERFACE.md](./IRIS_INTERFACE.md). They justify the names
used in shader source but do not replace empirical load testing against the pinned
Minecraft/Iris/Sodium stack.

The Iris world-uniform reference documents `sunAngle` phase (sunrise at 0, noon at
0.25, sunset at 0.5, midnight at 0.75), the Overworld sun/moon handover in
`shadowLightPosition`, and the Iris-exclusive `endFlashPosition` /
`endFlashIntensity` uniforms. The pack uses these for approximate celestial tint
and End-flash response; target-stack compilation and behavior remain unverified.

## Java adaptation of the supplied VV briefing

The user-provided briefing describes Bedrock resource-pack JSON, texture sets,
Script API, and unsupported RenderDragon shader replacement. These do not define
Java Iris pack interfaces. The implementation deliberately treats the briefing as
a visual reference and maps only effects expressible with the documented Iris
uniforms, textures, and passes. See [JAVA_26_3_VV_MAPPING.md](./JAVA_26_3_VV_MAPPING.md)
for the concept-by-concept mapping and exclusions.

## Visual calibration status

No local reference images were captured or committed; no Bedrock screenshot was
provided; no color samples or rubric scores are claimed. The warm sunset tint,
water Fresnel fallback, and small bloom are initial artistic approximations only.
