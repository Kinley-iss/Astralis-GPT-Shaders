# Feature matrix

| Feature | Status | Evidence / limitation |
| --- | --- | --- |
| Performance/Balanced/Quality profiles | APPROXIMATION | Profiles set Iris's actual `shadowMapResolution`/`shadowDistance` (256/32 blocks for Performance; 1024/80 Balanced), shadow filter taps and pixel steps, and optional effects. Screen-space ray tracing is disabled in Performance and Balanced and enabled in Quality. Profile application and FPS impact need runtime measurement. |
| Vanilla textures, vertex tints, and vertex AO | APPROXIMATION | Passed through in compatibility G-buffer shaders; Iris compile and runtime behavior unverified. |
| Sun/moon directional light and pixelated shadows | APPROXIMATION | `shadowLightPosition` supplies Iris's active celestial direction; `sunAngle` blends warm daylight/twilight and cool, faint moonlight into the vanilla lightmap. Iris's real shadow-map resolution and distance are configured in the pack defaults and profiles. Shadow-map UVs snap to a configurable 1/2/4/8-texel grid for hard pixel steps. Runtime coverage, bias, orientation and appearance still need in-game validation. |
| Vibrant sun and moon sprites | APPROXIMATION | Dedicated `gbuffers_skytextured` pass boosts vanilla celestial sprite brightness, warms the daytime sun and cool-tints the moon; existing bloom can add a restrained glow. Shape/size remain vanilla. |
| End flash lighting | APPROXIMATION | Iris `endFlashPosition` / `endFlashIntensity` add a restrained cool directional highlight to terrain, entities, and water reflections. No flash shadow or calibrated exposure. |
| Ambient and block light | APPROXIMATION | Vanilla lightmap color is retained while block-light contribution is increased by up to 65% based on its lightmap coordinate. This shader pass cannot identify the nearby source block, so Bedrock's distinct torch/redstone/soul/lantern/copper RGB values cannot be assigned per source. |
| Twilight and night color grading | APPROXIMATION | Solar elevation drives pastel pink/lilac twilight, a cool blue moonlit grade that preserves scene saturation, and rain dampening. Directional moonlight remains a modest lightmap-scaled approximation; not calibrated to Bedrock output and needs in-game validation. |
| Golden hour / rain grade | APPROXIMATION | Small time-of-day warm bias and rain desaturation; not calibrated to Bedrock references. |
| Underwater color filter | APPROXIMATION | `isEyeInWater` drives a stronger blue/cyan tint to evoke the clear underwater footage. Bedrock water absorption (CDOM, chlorophyll, sediment) uses JSON; Java has no per-block water color data. |
| Aerial/biome/weather fog | APPROXIMATION | Uses Iris `fogColor`, `fogStart`, and `fogEnd`; linear distance approximation only, no height fog or custom biome presets. |
| Water reflections and color | APPROXIMATION | All profiles use a Fresnel-weighted analytic sky/horizon reflection. Quality additionally traces bounded screen-space rays against opaque depth and blends hit color for visible scene reflections. It cannot see off-screen/occluded geometry; refraction, particle absorption, animated wave normals, and caustics remain unimplemented. Runtime appearance is unverified. |
| Foliage subsurface/backlight | APPROXIMATION | Green-albedo heuristic plus backlighting, so non-green foliage and other green materials may be misclassified. |
| Bloom and colour grade | APPROXIMATION | Thresholded four-direction bloom in composite plus luminance-adaptive vibrance and contrast in final. No HDR pipeline, temporal accumulation, or per-channel tone mapping. |
| Sky | APPROXIMATION | Preserves vanilla sky vertex colors and gently warms them at low sun; no analytic atmosphere or verified horizon model. |
| Clouds | APPROXIMATION | Leaves vanilla clouds to Minecraft; no infinite procedural clouds or self-shadowing. |
| Glass, foliage coloured shadows, material tables, emissive isolation | NOT DONE | No per-block properties/material classification or colored-shadow buffer. |
| Screen-space ambient occlusion/contact shadows | APPROXIMATION | Composite depth reconstruction with 4/8 neighbor discontinuity taps; shallow screen-space contact darkening only, not GTAO; may halo. |
| Sun shafts | APPROXIMATION | Composite samples bright sky pixels along the projected sun direction to produce screen-space shafts through openings. Not volumetric, temporally denoised, or a replacement for Bedrock's engine lighting; quality/strength controls trade cost for the effect. |
| Screen-space water reflections | QUALITY-ONLY APPROXIMATION | Composite marches a bounded ray against opaque `depthtex1` and gathers `colortex0` at a hit. It has screen-edge, disocclusion, and missing/off-screen geometry limitations; Iris depth conventions still need runtime validation. |
| One-bounce diffuse path lighting | QUALITY-ONLY APPROXIMATION | Two screen-space rays gather visible `colortex0` radiance once and add a restrained indirect term. It is not full-scene or hardware path tracing and has no temporal accumulation. |
| Additional settings/debug views | APPROXIMATION | Reflection cell size and Quality-only tracing controls are configurable; no debug visualizations, cloud mode, AA mode, or material controls. |
| Biome-specific settings and blends | NOT DONE | Preserves vanilla biome vertex tint and Iris fog inputs; no Bedrock client-biome identifiers, custom biome JSON, cubemap blending, or water-parameter blending. |
| PBR texture sets, local point lights, emissive isolation | NOT DONE | Bedrock MERS texture sets and local-light JSON are not Iris Java shader-pack interfaces; no per-block material data is available in this pack. |
| Volumetric atmospherics, automatic exposure, TAAU | NOT DONE | No ray-marched fog/light shafts, temporal exposure, temporal AA, or upscaling pass. |
| Dimension-specific grading | NOT DONE | No dedicated Nether/End palette beyond vanilla fog and Iris End flash. Underwater filter applies globally via `isEyeInWater`. |
| Iris compatibility on Minecraft 26.3 | NOT VERIFIED | No game load/compile evidence. |
| Target GPU performance | NOT VERIFIED | No target hardware performance capture. |
