# Astralis GPT — implementation report

## Summary

Astralis GPT now has a broader Iris shader source implementation inspired by the
lighting and atmosphere goals of Bedrock Vibrant Visuals. It includes source for
directional shadows, lightmap-aware shading, weather/fog and low-sun grading,
analytic water reflection, contact-occlusion approximation, bloom, and a final
display grade. Iris shader options include Low, Balanced, and High profiles that
change implemented effect costs. The project is packaged as a ZIP and includes an
interface allowlist, feature matrix, pass/buffer notes, manual testing protocol, and
known-issues/evidence logs. It has not been compiled or loaded in Minecraft, so it
remains an unverified shader prototype rather than a finished Bedrock VV recreation.

## Observed stack and machine

- Local game files: Minecraft 26.3; Fabric Loader profile 0.19.5; Iris 1.11.7;
  Sodium 0.9.2 (observed filenames/read-only inspection only).
- Java on PATH: Oracle Java 27 build 27+35-2325; not confirmed as the Minecraft
  runtime.
- Adapter detected: AMD Radeon(TM) Vega 3 Graphics, driver 31.0.21925.1001.
- The brief's Vega 8 target was not available on the observed adapter.
- OpenGL/GLSL strings and Fabric API version/hash are not verified.

## Evidence levels

- **L0:** Source, implementation notes, feature matrix, compatibility notes, and
  manual runtime protocol are present.
- **L1:** Static structure/options checks passed; deterministic ZIP built and
  inspected. See [TEST_LOG.md](./TEST_LOG.md).
- **L2:** Iris compile/link NOT VERIFIED.
- **L3:** In-game scenarios and visual fidelity NOT VERIFIED.
- **L4:** Performance NOT MEASURED; no FPS claims.

## Implemented approximations

- Depth-only directional shadow pass; one, four, or nine depth comparisons per pixel
  according to profile.
- Lightmap/vertex-tint lighting, a modest warm block-light bias, sun/moon-colored
  direct light, and a low-strength Iris End-flash response.
- Iris fog color/start/end, adjustable fog scaling, low-sun color warmth, and rain
  desaturation.
- Green-albedo foliage backlight heuristic.
- Fresnel-weighted analytic sky reflection and a small directional water glint.
- Four/eight-tap depth-discontinuity contact shading, thresholded low-tap bloom, and
  mild final contrast/saturation.
- Selectable Low/Balanced/High options for implemented quality controls.

## Important gaps

No screen-space reflections/refraction, full GTAO, volumetric fog/light shafts,
procedural infinite clouds, per-block material/PBR/emissive classification, colored
glass shadows, dimension-specific grading, or tested stability/performance. These
are detailed in [FEATURE_MATRIX.md](./FEATURE_MATRIX.md) and
[KNOWN_ISSUES.md](./KNOWN_ISSUES.md).

## Package and installation

ZIP: `dist/Astralis_GPT_0.1.0.zip`.

It contains `shaders/`, `README.md`, and `LICENSE` at its root. For manual testing,
copy the ZIP into the dedicated instance's `shaderpacks` folder, select Astralis GPT,
and use OpenGL. Follow [MANUAL_TEST_PROTOCOL.md](./MANUAL_TEST_PROTOCOL.md); do not
use this report as evidence of successful runtime loading.

The Bedrock-to-Java mapping and explicit non-portable features are documented in
[JAVA_26_3_VV_MAPPING.md](./JAVA_26_3_VV_MAPPING.md).
