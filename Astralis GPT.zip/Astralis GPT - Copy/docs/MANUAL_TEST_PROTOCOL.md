# Manual Test Protocol

All runtime evidence is currently **NOT VERIFIED**. Use a dedicated test instance and
do not alter the user's existing game directory or shader configuration.

1. Record Minecraft version, Java runtime version, loader, Iris and Sodium versions,
   operating system, GPU model, and graphics driver.
2. In the dedicated instance, select OpenGL in the graphics API setting if present.
   Iris shaders require the OpenGL renderer.
3. Copy the Astralis GPT folder into that instance's `shaderpacks` directory and select
   it in the shader menu. Capture a screenshot of the loaded pack and any error.
4. Inspect `logs\latest.log` for shader compilation/link errors and warnings. Save the
   relevant lines without editing the original log.
5. Repeat with `dist\Astralis_GPT_0.1.0.zip` after building the ZIP.
6. In daylight, confirm shadows follow the sun and inspect leaf cutouts; repeat at
   night to check moonlight direction. With entity/player shadows enabled, move the
   player in first or third person and check for a matching silhouette on nearby ground.
   Try each Shadow Pixel Size setting; walk and rotate slowly to check shimmer,
   peter-panning, acne, and shadow-distance fade.
7. Compare sunrise, noon, sunset, and midnight sky colors; repeat in rain and
   fog-heavy biomes. Check vanilla sun/moon sprites, stars, and clouds remain intact.
8. Inspect ocean/open water, shorelines, waterfalls, swimming, lava/powder-snow
   immersion, and glass; ensure reflections don't appear on all geometry.
9. Check entities, particles, first-person hand, armor glint, portals, beacons,
   damaged blocks, outlines, Nether, and End for altered rendering.
10. Look for missing textures, black/white surfaces, wrong transparency, flicker,
   lighting discontinuities, or broken hand/entity rendering. Record exact steps.
11. For performance, use the same world, position, render distance, resolution, and
   warm-up/capture duration for shader-off and shader-on runs. Record frame time and
   GPU/driver; do not infer FPS from estimates.
12. If any program fails, include its name, processed source line, log excerpt, and
   exact stack versions in the test report.
