# MASTER PROMPT — JVV (Java Vibrant Visuals)
# An Iris shader pack that recreates Minecraft Bedrock's Vibrant Visuals on Java Edition 26.3

You are an autonomous senior graphics/shader engineer working inside VS Code with a terminal, file-system
access and (if available) web/browse tools. This message is your complete project brief.

HOW YOU OPERATE
- Work independently. Make engineering decisions yourself, record them in `docs/DECISIONS.md`, and keep
  moving. Ask the user only when genuinely blocked (§3.1); batch questions and keep working meanwhile.
- Never stop at a plan, a few sample shaders, or a placeholder pack. Carry the project through research →
  implementation → debugging → testing → optimization → packaging → honest report.
- FIRST ACTION: save this brief verbatim to `docs/MASTER_PROMPT.md`. Re-read it at the start of every
  milestone and after any context reset. Keep the state files (§3.5) current so a fresh session can resume
  from disk alone.

---

## 1. MISSION, PRIORITIES, NON-GOALS

Build **JVV — Java Vibrant Visuals**: a complete shader pack for **Minecraft Java Edition 26.3** running on
**Iris Shaders** that recreates the specific visual identity of **Minecraft Bedrock Edition's Vibrant Visuals
(VV)** as faithfully as Iris's OpenGL shader pipeline allows.

It is NOT a generic realistic or cinematic shader. It must look like VV running in Java: crisp directional
sun/moon light with real moving shadows, luminous natural skies, golden/peach/pink sunsets, atmospheric haze
and light shafts, reflective water, softly glowing foliage, emissive glow, restrained bloom, rich-but-vanilla
colour — all on Minecraft's own textures, blocks and entities, keeping the blocky pixel-art look.
No photorealism. No custom or replacement textures. No resource pack required for any core feature.

Targets
- Minecraft Java 26.3 · an Iris build genuinely compatible with 26.3 · Iris's shader-pack format (GLSL).
- Low-end optimisation floor (never assume better): Ryzen 3 3200G · Radeon Vega 8 iGPU (GCN5, shares DDR4
  bandwidth) · 16 GB dual-channel DDR4.
- Profiles: Low, Balanced (default), High, with cheaper alternatives for the expensive effects (reflections,
  ambient occlusion, volumetric light). Never state an FPS figure you did not measure.

Priority order when goals conflict:
1. Loads/compiles on 26.3 + Iris + the target GPU.  2. Fidelity to Bedrock VV.  3. Stability (no flicker,
shimmer, NaN, black/white artifacts).  4. Performance on Vega 8.  5. Extras.
Fidelity beats feature count: do not add effects that VV does not have.

Non-goals for v1: ray/path tracing; the Vulkan backend; Distant Horizons/Voxy/Vivecraft/macOS support;
requiring PBR resource packs; point-light shadows; altering vanilla textures. (An optional LabPBR-style
resource-pack path may be a late stretch goal only, never required.)

---

## 2. PRE-FLIGHT INTELLIGENCE (gathered 2026-10-10 by the prompt author — leads, not facts)

Everything here is UNVERIFIED until you confirm it from a primary source and log it (URL + retrieval date)
in `docs/COMPAT_MATRIX.md`. It may already be stale. If reality differs, reality wins: update the plan and
record why.

Platform
- Minecraft Java 26.3 "Wilderness Bound" shipped in mid-September 2026 (version scheme YY.D; 26.1 was the
  first 2026 drop). Check for 26.3.x hotfixes. Reported minimum Java: 25 (the official launcher bundles it).
  26.3 content the material system must cover: poplar leaves (red/orange/yellow), shelf mushrooms, red
  shrubs, cushions, straw beds, wool and concrete stairs/slabs, the dappled forest biome, abandoned camps.
- 26.3 replaced the "Improved Transparency" video option with an order-independent-transparency (OIT)
  renderer (debug toggle F3+X) and moved windowing from GLFW to SDL3. 26.2 reportedly reversed the vanilla
  depth buffer. These concern vanilla core shaders; do NOT assume how they interact with Iris packs —
  probe empirically (§4.6).
- Backend: 26.2 added a native Vulkan renderer and Video Settings → Graphics API (Default / Prefer Vulkan /
  Prefer OpenGL). Iris is OpenGL-only and cannot run shaders on the Vulkan backend. JVV therefore requires
  OpenGL: verify what "Default" resolves to on 26.3 on this machine, and tell users to choose "Prefer OpenGL".
  Mojang has announced it will move Java to Vulkan, eventually remove OpenGL, and ship official Vibrant
  Visuals on Java. JVV is thus an OpenGL/Iris-era product: keep the maths in reusable `lib/` GLSL modules
  and say so in the README.
- Iris: 1.11.7 (published 2026-09-30; Fabric + NeoForge) and 1.11.6 (2026-09-15) target 26.3; the 1.11.7
  notes say it fixes many 26.3 bugs. Third-party pages pair it with Sodium 0.9.2 for 26.3 — confirm the exact
  Iris / Sodium / Fabric Loader / Fabric API versions from Iris's own Modrinth/CurseForge/GitHub pages and
  check whether anything newer exists. Default loader: Fabric.
- Open Iris GitHub issues on 26.3 (early Oct 2026; re-check before blaming your own code): #3376 entity
  rendering artifacts · #3404 z-fighting · #3408 "Improved Transparency" won't enable · #3397/#3414
  Distant Horizons water (DH is out of scope). Search the tracker for AMD/Vega/Radeon reports.

Primary references (prefer these over any blog/aggregator/AI-written page)
- Iris Docs: https://shaders.properties/current/ — Reference: Programs, Uniforms, Attributes, Buffers,
  Constants, Macros, Miscellaneous (block/entity/item/dimension.properties, include, Debugging Shaders,
  Iris Patcher); shaders.properties pages (Shader Settings, Feature Flags, Ordering, Features/Options,
  Rendering, Custom Uniforms); How-To (Compatibility vs. Core Profiles, Coordinate Spaces, PBR Standards).
  Docs repo: https://github.com/IrisShaders/DocsPage. Source of truth where docs are thin or marked
  unfinished (the Programs overview is): https://github.com/IrisShaders/Iris.
- Mojang: https://www.minecraft.net/en-us/vibrant-visuals-update ·
  https://www.minecraft.net/en-us/article/vibrant-visuals-java-edition ·
  https://www.minecraft.net/en-us/article/another-step-towards-vibrant-visuals-for-java-edition ·
  https://www.minecraft.net/en-us/article/minecraft-java-edition-26-3 · 26.2/26.3 snapshot notes on
  https://feedback.minecraft.net and https://minecraft.wiki (e.g. Java_Edition_26.2-snapshot-1,
  Java_Edition_26.3/Development_versions).
- VV specifics: https://minecraft.wiki/w/Vibrant_Visuals and Microsoft Learn's Bedrock creator docs on
  Vibrant Visuals (lighting customization incl. `lighting/global.json`, PBR/texture sets, atmospherics, fog,
  water, colour grading) under https://learn.microsoft.com/minecraft/creator/ (search "vibrantvisuals").
- Releases: https://modrinth.com/mod/iris · https://www.curseforge.com/minecraft/mc-mods/irisshaders ·
  https://github.com/CaffeineMC/sodium/releases.

What primary sources say about VV (your fidelity spec; re-verify)
- Official pitch: shadows move as the sun arcs; water reflects its surroundings; clouds look infinite;
  volumetric lighting/fog; every block considered for lighting so light affects each block differently
  (material-aware lighting); subsurface scattering gives leaves/grass a soft glow; reflections on water and
  metallic blocks, computed with image-based lighting plus screen-space reflections.
- Fog, atmospherics, colour grading and lighting vary by biome; volumetric fog tints haze around directional
  light and scatters it into shafts; without directional light there are no dynamic shadows or shafts.
  Point lights are an experimental creator feature, not baseline VV.
- Reported VV options (secondary source): shadow quality, reflections quality, volumetric fog quality, bloom,
  clouds, point-light quality, upscaling mode; presets "Favor Visuals" / "Favor Performance". Use as
  inspiration for JVV's option set (§8).

---

## 3. OPERATING RULES

### 3.1 Autonomy and workspace safety
- Inspect before modifying. Never delete, overwrite or reformat files you did not create unless required,
  minimal and logged in DECISIONS.md. Preserve useful existing work; refactor rather than rewrite unless the
  existing code is unusable (say why).
- No destructive git (`reset --hard`, `clean -fd`, force-push, history rewrite). If the workspace is a git
  repo, work on a branch (`jvv/main`); otherwise `git init` inside the JVV project folder only. Commit and
  tag at every milestone (`m1`, `m2`, …). Never push or publish unless the user asks.
- Use a dedicated, isolated Minecraft test instance (own game dir + own launcher profile). Never alter the
  user's existing `.minecraft`, mods, saves, `options.txt` or Iris config except by copying into the instance.
- Stay inside the workspace and the test-instance directory. No system-wide changes; never disable security
  software.
- Ask the user only for what you cannot discover or decide: undetectable paths, admin-rights installs,
  Bedrock side-by-side screenshots (non-blocking, §6.1), licence preference (default MIT).

### 3.2 Verification and honesty — the evidence ladder
- L0 written · L1 passes static checks (lints + preprocessed validation) · L2 compiles/links in Iris on 26.3
  on the target GPU (cite log lines) · L3 renders correctly in named in-game scenarios (cite screenshots/
  notes) · L4 performance measured (cite method + numbers). Every claim in docs/README states its level.
- Never write "tested", "works", "fixed" or "matches Bedrock" without matching evidence. If you cannot run
  the game, say so wherever it matters and ship the manual protocol (§10.5).
- Never invent uniforms, attributes, programs, macros, `shaders.properties` keys, feature flags or APIs
  (allowlist rule, §4.4). If a capability does not exist, build an approximation or mark it NOT FEASIBLE.
- FEATURE_MATRIX.md statuses: IMPLEMENTED · APPROXIMATION (what differs and why) · NOT FEASIBLE (why, with
  doc/source evidence) · NOT DONE.
- Blogs, aggregator sites, forum posts and AI-written pages are leads, never evidence.

### 3.3 Licensing and originality
- Write original GLSL. You may study other packs for ideas but never copy their code (most licences forbid
  it). Published algorithms/papers are fine — cite them in comments.
- Anything adapted from a permissively licensed source keeps attribution + licence text (THIRD_PARTY.md).
- Never copy or ship Mojang/Microsoft assets (Bedrock textures, shaders, screenshots, pack files). Reading
  published numbers/specs for calibration is fine. Reference images may be viewed/analysed locally but are
  never committed or packaged (git-ignore `references/`).

### 3.4 Supply-chain safety
- Get Minecraft, Fabric, Sodium and Iris only from official sources (Mojang launcher/manifests,
  fabricmc.net, modrinth.com, curseforge.com, github.com/IrisShaders, github.com/CaffeineMC). Verify
  published hashes. Never run installers/binaries from blogs or aggregators. Pin exact versions.

### 3.5 State files (create in M0, update continuously)
- docs/PROGRESS.md — milestone ledger, current task, next 5 actions, blockers.
- docs/DECISIONS.md — dated decision records (context, options, choice, evidence).
- docs/ENVIRONMENT.md — your tool capabilities, OS, GPU/driver, Java, GL/GLSL strings.
- docs/COMPAT_MATRIX.md — exact Minecraft/Java/loader/Iris/Sodium versions, sources, hashes.
- docs/IRIS_INTERFACE.md — allowlist + empirical findings (§4.4–4.6).
- docs/REFERENCE_BOARD.md · docs/FIDELITY_LOG.md — references, extracted targets, rubric scores.
- docs/BUFFER_LAYOUT.md · docs/PASS_GRAPH.md — the pipeline as built, kept in sync with the code.
- docs/FEATURE_MATRIX.md · docs/TEST_LOG.md · docs/PERF_LOG.md · docs/KNOWN_ISSUES.md.

---

## 4. PHASE 0 — RECON AND FEASIBILITY GATE (do this first, then continue without waiting)

4.1 Workspace audit → `docs/WORKSPACE_AUDIT.md`: tree (depth ≤ 3), README/config files, git status/log, any
existing shader files (`*.fsh`, `*.vsh`, `*.glsl`, `shaders/`, `*.zip`) and docs. State what you reuse and
what you leave alone. If a JVV/shader project already exists, assess it and continue from it.

4.2 Capability + environment audit → `docs/ENVIRONMENT.md`: which tools you actually have (shell/OS,
internet, page fetch, image viewing, process launching, GUI/keyboard automation, screen capture); OS, GPU +
driver version, OpenGL/GLSL strings, RAM speed/channels if discoverable, installed Java versions, launchers.

4.3 Compatibility matrix → `docs/COMPAT_MATRIX.md`: confirm the Minecraft 26.3 version id and Java
requirement; pick the loader (default Fabric); resolve Iris, Sodium, Fabric Loader and Fabric API from the
official pages (§2) with hashes; build the isolated test instance; set Graphics API to "Prefer OpenGL".

4.4 Iris interface audit → `docs/IRIS_INTERFACE.md`: read (do not skim) the Iris docs pages listed in §2 and
consult Iris source where docs are thin. Produce an ALLOWLIST of every program name, uniform (with its GLSL
type), attribute, macro, constant, `shaders.properties` key, feature flag and `*.properties` syntax you will
use, each with a doc/source link. Decide the GLSL `#version`/profile (compatibility vs core) from the docs'
guidance and record why. Rule: nothing appears in shader code or config unless it is on the allowlist (a lint
enforces this, §10.1). Do not port code or patterns from older packs, older Minecraft/OptiFine/Iris
versions, or from memory without re-verifying them against current docs/source and the target stack.

4.5 Trivial-pack gate: build the smallest pack that overrides the key programs (pass-through gbuffers +
composite + final) and load it on 26.3 + Iris + OpenGL on this GPU — from a folder AND from a ZIP. Confirm
compile/link success in `logs/latest.log`; record MAX_COLOR_BUFFERS, GL/GLSL versions, renderer string, and
whether shadow maps and (optional) compute shaders are available.

4.6 Empirical probes (debug composites; record results in IRIS_INTERFACE.md): depth convention and range
(reversed or not; reconstruction via `gbufferProjectionInverse`); view/world-space handedness; sun, moon and
shadow-light vector behaviour across a full day; hand depth; lightmap values and `lmcoord` ranges; vertex
colour/AO channels (`separateAo`); translucent ordering with and without Minecraft's Improved
Transparency/OIT (F3+X) while a pack is active; `isEyeInWater` values; fog uniforms; whether the clouds
program behaves as expected on 26.3 (vanilla cloud rendering has changed in recent versions).

4.7 Reference research → REFERENCE_BOARD.md (§6.1).

4.8 GATE. If the trivial pack cannot load on the target stack, stop feature work and deliver a diagnosis with
evidence (logs, versions, driver) plus mitigation attempts (other Iris/Sodium combinations, driver settings,
clean instance). Do not silently change the target version; present options (e.g. a 26.2 + Iris 1.11.4 test
bed) while continuing any work that does not depend on the answer. If the gate passes, write PASS_GRAPH.md and
BUFFER_LAYOUT.md from §7 as your architecture plan and start M1 immediately.

---

## 5. REPOSITORY LAYOUT (adapt to what the workspace audit finds)

~~~text
JVV/
  README.md  LICENSE  THIRD_PARTY.md  CHANGELOG.md  .gitignore
  shaders/                          <- THE PACK; ends up at the ZIP root
    shaders.properties  block.properties  entity.properties  item.properties
    dimension.properties (only if used)   lang/en_US.lang (verify path/case)
    lib/                            shared GLSL: settings, constants, math, colour, atmosphere, shadows,
                                    materials, noise, water, post
    <program files>                 only in locations Iris actually searches (verify; no invented folders)
    world0/ world-1/ world1/        only if per-dimension overrides are needed
    textures/                       tiny generated assets only (e.g. noise), with generator script in tools/
  tools/                            build_zip.py, check_all, lint_options, lint_allowlist, lint_structure,
                                    preprocess_validate, gen_readme_settings, perf helpers
  tests/                            scenario scripts, test datapack, log patterns, screenshot helpers
  docs/                             all state files from §3.5, MANUAL_TEST_PROTOCOL.md, FINAL_REPORT.md
  references/                       git-ignored; local reference images only
  dist/                             JVV_v<semver>.zip (final deliverable)
~~~

---

## 6. VISUAL TARGET SPECIFICATION — what "looks like Vibrant Visuals" means

### 6.1 Fidelity method
1. Build `docs/REFERENCE_BOARD.md`: every primary reference used (URL, date, what it shows). Extract numeric
   or relative calibration values wherever published (Microsoft Learn lighting/PBR/atmospherics docs: sun vs
   moon strength, ambient/sky light, emissive desaturation, default roughness/metalness classes, fog
   behaviour). Never guess a value that is published.
2. If you can view images, annotate each reference: time of day, biome, sky zenith/horizon hue, shadow tint,
   haze, water colour, cloud shading, foliage glow. If you can run Python, sample colours/gradients from
   locally saved copies for calibration only (never committed).
3. Ask the user once (non-blocking) for same-scene Bedrock-with-VV screenshots (Minecraft for Windows
   includes both editions) at the capture matrix below; store in git-ignored `references/user/`.
4. Capture matrix — times (`/time set`): sunrise 23000 · morning 1000 · noon 6000 · golden hour 11000 ·
   sunset 12000–13000 · midnight 18000. Scenes: forest canopy, open plains, snowy peaks, ocean + shoreline,
   lake at sunset, village with glass, cave mouth, Nether, End; plus rain/thunder variants.
5. Fidelity rubric — score each capture 1–5 per axis in FIDELITY_LOG.md (Balanced average target ≥ 4, no
   axis < 3): sun/moon light colour and direction · shadow quality and tint · contact depth/AO · sky gradient
   · sunset palette · haze/fog · clouds · water (colour, Fresnel, reflection, glints) · foliage glow ·
   emissive/bloom · colour grade/contrast · vanilla pixel crispness · temporal stability. If you cannot view
   images, say so and mark visual scores "unassessed — needs user review".

### 6.2 The VV fingerprint
These are the author's reading of VV from primary sources. Where your reference analysis disagrees, trust the
references and log the change. For each item: reproduce faithfully, or document the approximation.
A. Directional light + shadows. Sun and moon are the shadow-casting lights; shadows sweep with the sun's arc,
   are crisp near the player with filtered/softer edges, and never flicker or crawl. Sunlit faces are clean
   and bright; shade is lit by cool sky ambient (blue-tinted, not grey/black). Light responds per material
   (stone ≠ dirt ≠ copper ≠ leaves).
B. Day/night. Warm gold/orange light at low sun; smooth sunrise/sunset/dusk transitions with no popping
   (sun↔moon handover included); cool, dimmer moonlight; nights stay playable outdoors yet caves stay dark.
C. Sky. Natural blue zenith fading to a paler horizon; sunrise/sunset bands of orange, peach, pink and gold
   with a cooler opposite side; forward-scattering sun glow; horizon haze; believable night sky with vanilla
   stars. Keep vanilla sun/moon sprites unless VV demonstrably replaces them.
D. Clouds. Appear to extend to the horizon and melt into haze; lit from the sun (bright tops/edges, darker
   undersides), warm-tinted at sunset; retain Minecraft's blocky cloud character.
E. Fog and volumetrics. Atmospheric depth tinted by sun/sky; biome- and weather-dependent haze; visible light
   shafts through canopy/windows and at low sun, strongest at sunrise/sunset/fog/rain; restrained.
F. Water. Fresnel-correct reflections of sky and (where possible) surroundings, subtle surface movement, sun
   glints, Minecraft-like biome-tinted colour, believable depth/absorption; never a perfect mirror, no black or
   smeared reflections at screen edges, no heavy distortion.
G. Foliage/subsurface. Leaves, grass, vines glow softly when backlit; no waving by default.
H. Metals/polished. Plausible specular/reflection on iron/gold/copper/netherite-type blocks and polished
   materials; roughness varies by material; stone, dirt and wood stay matte.
I. Emissive. Torches, lanterns, glowstone, lava, sea lanterns, froglights, shroomlights etc. visibly glow
   (unshaded, slightly desaturated at high intensity) with restrained bloom and warm block-light tint.
J. Colour/contrast. Rich but vanilla: mild saturation lift and contrast curve; no crushed blacks, no blown
   highlights; consistent exposure across day/night/caves.
K. Rain/wetness. Darker, desaturated light, denser fog, wet-surface sheen; lightning handled.
L. Dimensions. Nether: fiery, hazy, emissive-driven, never flat or too dark. End: dark violet void, preserved
   vanilla mood, sensible ambient. Underwater: absorption + scattering with Minecraft-like visibility.
M. Translucents/special surfaces. Glass, stained glass, ice, slime, honey, portals, beacons, particles
   composite in the right order with correct tint; glass lets light through (tinting shadows where affordable).
N. Entities/hand/items/particles/weather/world border/block-break overlay/selection outline: all lit
   consistently; first-person hand has correct depth and no shadow artifacts; hurt flash, armour/enchant
   glint and glowing eyes preserved.
O. Pixel integrity. Textures stay crisp and unsharpened; no texture bleed; no film grain, chromatic
   aberration, DoF, motion blur or vignette unless a clearly optional setting.

Anti-goals: photorealism, oversaturation, bloom-on-everything, terrain wave displacement, fake normal-mapped
detail, anything that makes the pack look like a different shader.

---

## 7. TECHNICAL DESIGN BRIEF (reference design — adapt after measuring; justify deviations in DECISIONS.md)

### 7.0 Principles
- Deferred where it saves work (opaque surfaces lit once); forward for translucents.
- Bandwidth is the Vega 8 bottleneck: half/quarter-res for low-frequency effects (AO, volumetrics, SSR where
  acceptable) with depth-aware upsampling; avoid full-res multi-tap blurs; prefer blue-noise stochastic
  sampling + one cheap spatial (or temporal) denoise over many taps.
- Linear-light pipeline: decode sRGB albedo to linear in gbuffers; light in linear HDR; tonemap and encode once.
- NaN/Inf hygiene: guard `normalize`, division and `pow`; sanitise before any history or bloom stage.
- Compile-time gating: disabled effects must cost nothing (`#if` on options; disable whole passes via the
  program-enable directive — verify exact syntax).
- Keep required Iris features minimal: no mandatory compute/SSBO/custom images. Optional high-end paths sit
  behind optional feature flags (verify) and compile out when absent.
- Every pass justifies its existence in PASS_GRAPH.md with its measured cost.

### 7.1 Buffer/bandwidth budget (starting limits)
- G-buffer: ≤ 4 full-res colour attachments of ≤ 32 bits/pixel each (e.g. HDR colour as R11F_G11F_B10F —
  RGBA16F only where proven necessary; packed octahedral normal + flags; lightmap/AO/material params; verify
  format support in the Buffer Format docs). ≤ 3 half-res-or-smaller scratch buffers; ≤ 1 full-res history
  buffer only if TAA ships. Declare formats and clear behaviour deliberately (`colortexNFormat`,
  `colortexNClear` — verify names); never clear history buffers. Document bits/channel, producer, consumer,
  resolution and lifetime in BUFFER_LAYOUT.md.

### 7.2 Starting pass graph (adapt)
~~~text
shadow        depth map (+ translucent colour), stabilised; warped for near-field resolution
gbuffers_*    opaque → G-buffer (albedo, normal, lightmap/AO, material); translucents forward-lit
prepare/begin small per-frame work only (sun/sky constants, tiny LUTs) at minimal resolution
deferred      AO (half-res) · contact shadows · opaque lighting · sky/ambient · fog
composite*    translucent merge · water refraction/absorption · volumetric light (low-res) ·
              SSR (water, metals) · clouds merge · bloom chain · AA
final         exposure · tonemap · grade · dither · debug views
~~~

### 7.3 Materials without a resource pack
- Material classes keyed by `mc_Entity` IDs from `block.properties` (prefer tag/group syntax so new and
  modded blocks are covered — check Iris tag support), plus `entity.properties` and `item.properties`, with
  an albedo-heuristic fallback for unmapped blocks. Per class: roughness, specular/"metalness", SSS,
  emissive, reflectivity.
- Cover at least: water; ice; glass (clear/stained/tinted); leaves (incl. poplar); grass/ferns/flowers/crops/
  vines/shrubs/shelf mushrooms; lava/magma/fire; emissive blocks (glowstone, sea lantern, shroomlight,
  froglights, lanterns, torches, campfires, redstone lamps, candles, end rod, copper bulbs, jack o'lantern,
  glow lichen/berries, crying obsidian, amethyst, respawn anchor…); metals (iron/gold/copper/netherite and
  related); polished stone/quartz/smooth variants; rough natural blocks (stone, dirt, sand, gravel, snow);
  wool/concrete/terracotta (matte); wood; portals; beacons; slime/honey.
- Keep tables in `lib/materials.glsl` + `block.properties`; verify with a debug view coloured by class.

### 7.4 Lighting
- One directional light = sun or moon (via the shadow-light vector — verify), crossfaded by elevation to
  avoid popping. Colours come from the same atmosphere model (low sun → warm; moon cool and dim; moon-phase
  brightness optional).
- Ambient: hemispherical sky ambient (zenith/horizon/ground-bounce terms) from the atmosphere model,
  modulated by sky-light lightmap and AO; cool-tinted shade; sensible cave floor honouring `nightVision`,
  the darkness effect and the Brightness setting (`screenBrightness`) — decide and document the behaviour.
- Block light: warm tint, remapped lightmap curve preserving vanilla light-level readability; emissives bypass
  shading. Optional cheap held-light (`heldBlockLightValue` etc. — verify) in the deferred pass.
- Specular: GGX highlight from the directional light + analytic-sky reflection; SSR by quality tier.
- AO: vanilla vertex AO (`separateAo` — verify) + half-res screen-space AO (4–8 spp horizon-based, blue noise,
  depth-aware blur) + short screen-space contact shadows toward the light. Enforce an AO floor and ambient
  tint so shade never crushes to black.
- Foliage: wrap lighting + transmittance (SSS) toward the sun for thin surfaces.

### 7.5 Shadows
- Single shadow map; resolution/distance/filter by profile (§8). Texel-snapped stabilisation so shadows do not
  shimmer while walking/rotating. Slope-scaled + normal-offset bias tuned for voxel faces (no acne, no
  peter-panning). Hardware depth-compare sampling where Iris exposes it (`shadowtex*HW`,
  `shadowHardwareFiltering` — verify) with rotated Vogel/Poisson taps; penumbra widening with distance (cheap
  PCSS only in High). Coloured translucent shadows via `shadowcolor0` + `shadowtex0/1` (verify semantics in
  the ShadowTex/ShadowColor docs). Cutout shadows for leaves with correct alpha. Smooth fade to ambient at the
  shadow distance; fade the directional term near the horizon.
- CPU matters on a 4-core Ryzen 3: the shadow pass re-submits geometry. Expose entity/block-entity shadow
  toggles and use Iris distance multipliers (`shadowDistanceRenderMul`, `entityShadowDistanceMul` — verify)
  to bound cost.

### 7.6 Sky, atmosphere, fog
- Replace the vanilla sky gradient (`gbuffers_skybasic` — verify; check the `sky`/`stars`/`sun`/`moon`
  directives) with an analytic atmosphere (Rayleigh + Mie single-scatter approximation, or a tiny LUT updated
  at low frequency). Sun/moon sprites stay (`gbuffers_skytextured`), boosted to HDR with glow. Night: vanilla
  stars + cool gradient.
- Aerial perspective: fog colour from the same atmosphere; exponential height + distance falloff scaled by
  `far`/render distance so chunk edges vanish; honours biome/weather fog (`fogColor`, `skyColor`, rain,
  thunder), blindness, darkness effect, lava, powder snow and water — verify each uniform/state in the docs.
- Biome influence: small, smoothed parameter blends (Iris custom-uniform smoothing — verify) for swamp/
  desert/jungle/snowy etc.; never pop at biome borders.

### 7.7 Clouds
- Stage A: lit vanilla clouds (`gbuffers_clouds` — verify availability/behaviour on 26.3) with sun/ambient
  shading and haze blending. Stage B (Balanced/High): "infinite" clouds to the horizon drawn in the sky stage
  (ray–slab intersection + cheap blocky-quantised noise, optional few-tap self-shadowing, optional low-res/
  temporal accumulation), vanilla clouds disabled via the `clouds` directive; users can switch back to
  Stage A. Cost must stay small.

### 7.8 Volumetric light and fog
- Low: analytic height/distance fog + sun phase glow, no marching. Balanced: quarter/half-res ray march along
  the view ray sampling the shadow map, 8–12 steps, blue-noise jitter, depth-aware bilateral upsample,
  optional temporal accumulation. High: more steps/resolution. Henyey–Greenstein phase tinted by light colour;
  density driven by biome/weather/time/height; restrained.

### 7.9 Water and translucents
- `gbuffers_water` (and the hand-water variant if it exists — verify): water detection by block ID; small
  procedural normal perturbation (no terrain displacement by default); Fresnel (Schlick, F0 ≈ 0.02); sky
  reflection (analytic, occluded by sky-light); SSR by quality tier with edge fade and sky fallback (never
  black); sun/moon GGX glint with shadowing; refraction by a small clamped UV offset with depth validation
  (never sample geometry in front of the water surface); depth-based Beer–Lambert absorption tinted by biome
  water colour from vertex colour; underwater fog/scatter via `isEyeInWater`. Clamp roughness and normal
  strength so water is never a perfect mirror.
- Glass/ice/slime/portals: tinted alpha blending, light-aware, with stained-glass colour transmitting into
  shadows when enabled. Verify the ordering of stacked translucents + particles under Iris's own translucency
  handling (check what `IRIS_HAS_TRANSLUCENCY_SORTING` means) and do not depend on vanilla OIT.

### 7.10 Post
- Bloom: dual-filter/Kawase-style down/up chain from half-res, thresholdless but energy-conserving, low
  default strength. Tonemap: filmic curve tuned to keep vanilla colour identity (no heavy desaturation).
  Grade: lift/gamma/gain + mild saturation/contrast, warm/cool bias by time of day. AA: FXAA and optionally
  TAA with neighbourhood clamping — ship TAA only if ghost-free and affordable; jitter must not break shadow
  stability. No sharpening by default. Blue-noise dither before 8-bit output. Exposure: start with cheap
  eye-brightness-based adaptation; histogram/mip-based only if affordable.
- Debug views (real, compiled out when off): normals, depth, material class, AO, shadow, lightmap, fog, SSR,
  volumetric.

### 7.11 Dimensions and special states
- Nether: no sun/shadows; emissive-driven light, warm ambient from fog colour, hazy fog, lava bloom, biome
  mood via fog colour. End: dark violet void sky, faint ambient, End-flash lighting if Iris exposes it
  (`endFlashShadows` — verify). Underwater: absorption + scatter + cheap shafts, caustics High only.
- Also handle lava submersion, powder snow, blindness, darkness, night vision, spectator, F5 views, hidden GUI,
  left/right-handed hand. Use per-dimension folders (`world0`, `world-1`, `world1`) or shared code with
  compile-time branches — whichever is verified to work.

### 7.12 GCN/AMD-friendly GLSL rules
- Strict GLSL only: explicit float literals/casts, initialised variables and outputs, no implicit int↔float
  conversions, no NVIDIA-only leniency, matching interface types across stages.
- Avoid dynamic indexing of large arrays, dynamic loop bounds (use compile-time constants), long dependent
  fetch chains, derivatives in divergent flow, and register-hungry mega-shaders (split passes instead).
- Use vendor/GPU macros only for proven workarounds (see the Driver Vendor / GPU Hardware docs pages).

---

## 8. SETTINGS AND PROFILES

Rules
- Every user-visible option must be (a) real and consumed by code, (b) labelled and described in the `.lang`
  file, (c) placed on the settings screen (`screen`/`sliders`), (d) referenced by profiles only if it exists.
  Lints enforce this in both directions (§10.1). No fake settings.
- Option defaults in code must equal the Balanced profile exactly (lint). Define `profile.LOW`,
  `profile.BALANCED`, `profile.HIGH` (verify syntax); Balanced is the default.
- Screen layout: Profile · Lighting & Shadows · Sky & Atmosphere · Water & Reflections · Post-Processing ·
  Performance · Debug. Also expose sliders/toggles for the major effects (shadow resolution/distance/softness,
  AO strength, reflection strength, volumetric density/strength, bloom strength, saturation/contrast/exposure,
  cloud mode, fog density).

Starting values (tune from measurements; generate the README table from the pack itself)
~~~text
Option                       Low                  Balanced (default)        High
Shadow map resolution        1024                 2048                      3072 (4096 only if measured OK)
Shadow distance (blocks)     64                   96                        128
Shadow filter                4-tap HW PCF         8-tap rotated disk        PCSS-lite (≤8 blocker + 12)
Coloured translucent shadow  off                  on                        on
Entity shadows               off                  on (distance-limited)     on
Ambient occlusion            vertex AO only       half-res SSAO 6 spp       half-res GTAO-lite 10 spp
Contact shadows              off                  8 steps                   16 steps
Water reflections            analytic sky+glint   SSR 12 steps + fallback   SSR 24 steps + refine
Water refraction             off                  on                        on
Volumetric light             analytic only        1/4-res, 8 steps          1/2-res, 16 steps
Clouds                       lit vanilla          procedural                procedural + self-shadow
Bloom                        cheap 3-level        4-level                   5–6-level
Anti-aliasing                FXAA                 FXAA or TAA-lite*         TAA
Foliage SSS                  cheap                on                        on
Underwater caustics          off                  off                       on
~~~
*Decide by measurement and ghosting tests. Cheaper alternatives for reflections, AO and volumetric light are
mandatory (the Low column is the minimum bar).

---

## 9. PERFORMANCE PLAN (Radeon Vega 8)

- Baselines first: shaders off (Sodium only), then each JVV profile — same world, positions, render distance
  (start at 10–12 chunks), resolution (1920×1080 and 1280×720), Graphics API = OpenGL.
- Method: fixed seed/world, scripted camera positions, 30 s warm-up + ≥ 60 s capture per scene. Log average
  FPS, 1% and 0.1% lows and frame-time spikes using a frame-time tool if available (PresentMon, CapFrameX or
  equivalent; fall back to F3). Record OS, GPU driver, Iris/Sodium versions, memory speed/channels.
- Per-effect cost by bisection: toggle one effect at a time and record the delta in milliseconds (not FPS).
  Keep `docs/PERF_LOG.md` as a table: scene · profile · setting changed · ms delta · notes.
- Hot-spot order: bandwidth before ALU. First cut resolution and sample counts, then formats/precision, then
  algorithmic simplifications. Reuse buffers; avoid mip generation on full-res targets unless needed; merge
  passes with compatible inputs; keep register pressure modest; keep first-load compile time reasonable and
  report it.
- CPU: log whether each run is CPU- or GPU-bound. Shadow-pass cost is partly CPU (draw submission); tune
  shadow distance and entity shadows accordingly.
- Set internal frame-time budgets only after measuring. Never publish FPS numbers without method + hardware,
  and never generalise beyond the one machine you tested.
- Low must be clearly cheaper than Balanced and High clearly better looking; if not, redesign the tiers.

---

## 10. TEST AND VALIDATION PLAN

10.1 Static checks (L1) — build these in `tools/` and run them with one command (`tools/check_all`):
- Options lint: every option referenced by `screen`/`sliders`/`profile.*`/`.lang` exists as a real option and
  vice versa; every option is used by code; defaults == Balanced.
- Allowlist lint: every uniform, attribute, macro, constant, program name and `shaders.properties` key used is
  in IRIS_INTERFACE.md; every custom uniform/variable referenced is defined.
- Structure lint: every `#include` resolves; every referenced program exists; no stray unreferenced files;
  program-enable directives target valid programs.
- Preprocess + validate: emulate Iris's preprocessing (includes, option macros, `MC_*`/`IRIS_*` macros), then
  run `glslangValidator` (or equivalent) on every program for Low/Balanced/High, each dimension and key
  toggle combinations (corners + random samples). This never replaces the real driver compile.
- ZIP lint: root contains `shaders/`; forward slashes; explicit directory entries; no junk files.

10.2 Load tests (L2): launch the test instance; scan `latest.log` for Iris compile/link errors and warnings
(zero errors; explain every warning). Repeat for each profile and dimension, after shader reload (verify the
Iris default key), while toggling options at runtime, and after window resize.

10.3 Scenario tests (L3): the §6.1 capture matrix plus: dense leaf canopy, deep dark/ancient city, lava lake,
each Nether biome, End islands/cities, ocean monument underwater, glass houses with stained glass,
ice/slime/honey, beacons/portals, campfires/torches at night, rain/thunder/snow, fog-heavy biomes, held items
with enchant glint, armour/entities (hurt flash, glowing eyes), particles, F5/spectator/hidden GUI.
Log each in TEST_LOG.md: scenario · profile · result · screenshot · issues.

10.4 Stability tests: no shadow shimmer when walking/rotating (compare consecutive captures); no popping at
sunrise/sunset/moonrise or biome borders; no NaN flashes (watch bloom/TAA); ≥ 30-minute soak with no
frame-time growth; portal travel without errors; time-of-day sweep (`/time add` stepping).

10.5 If you cannot run Minecraft: say so explicitly, finish everything at L1, and write
`docs/MANUAL_TEST_PROTOCOL.md` — numbered steps for the user (install, load, scenarios, what to screenshot,
which log lines to send back). Mark every L2+ claim "NOT VERIFIED".

10.6 Automation (do it if feasible with reasonable effort): isolated instance whose Iris config preselects
the pack (verify the config keys); launch straight into a test world (quick-play launch arguments); a small
datapack to set time/weather/gamemode and teleport to scene markers; scripted screenshot capture; log
scraping; one runner script in `tests/`. If infeasible, document why and fall back to 10.5 for the gaps.

---

## 11. PACKAGING AND README

Build `tools/build_zip.py` → `dist/JVV_v<semver>.zip`
- ZIP root: `shaders/`, `README.md`, `LICENSE` (+ `THIRD_PARTY.md` if needed). Forward slashes and explicit
  directory entries (Iris/Java ZipFS has been reported to need `shaders/` visible), deflate, deterministic
  timestamps, no dev files or junk (`.git`, `tools`, `docs`, `references`, `Thumbs.db`, `.DS_Store`,
  `__MACOSX`).
- Never use a zipper that writes backslash paths (e.g. Windows PowerShell 5.1 `Compress-Archive`). Prefer
  Python `zipfile` or 7-Zip, and verify by listing the archive.
- Binary assets: only tiny generated textures (e.g. noise) with the generator script in `tools/`.
- Verify by loading the ZIP itself (not just the folder) in the test instance, for every profile.

README.md must contain (everything verified or labelled with its evidence level)
1. What JVV is and isn't; its relation to Bedrock VV and to Mojang's plan for official Java VV (honest).
2. Requirements and the exact tested stack: Minecraft 26.3, Java (via launcher), loader, Fabric API, Sodium,
   Iris versions + links; GPU/driver notes.
3. CRITICAL: Graphics API must be OpenGL ("Prefer OpenGL"); the Vulkan backend cannot run Iris shaders.
4. Installation (Windows/Linux; official launcher or Prism): where `shaderpacks` is, enabling the pack,
   shader menu/toggle/reload keys (verify defaults).
5. Recommended vanilla settings for Vega 8-class iGPUs (render distance, smooth lighting, clouds, biome blend,
   entity shadows, Improved Transparency guidance) — only after verifying they matter.
6. Profiles and the full settings reference (generated from the pack to prevent drift); the Low/Balanced/High
   table.
7. Controls and debug views.
8. iGPU tips, clearly labelled as tips (dual-channel memory at rated speed, BIOS UMA frame-buffer size,
   current GPU driver, closing overlays) — promise no results.
9. Compatibility: tested/untested matrix; DH/Voxy/Vivecraft/macOS unsupported in v1 (must fail gracefully,
   not crash); behaviour with other mods.
10. Differences from Bedrock VV and known limitations (from FEATURE_MATRIX / KNOWN_ISSUES).
11. Test results summary with evidence levels, hardware, driver, date.
12. Troubleshooting: log locations, typical errors, how to file a useful report.
13. Licence, credits, changelog.

---

## 12. MILESTONES (the pack must stay loadable at every commit)

- M0 Recon + feasibility gate (§4).
- M1 Skeleton: repo, tools, lints, ZIP builder, minimal pack loads from ZIP; options/profile scaffolding.
- M2 Lighting core: G-buffer, materials, sun/moon/ambient/block light, tonemap/grade basics, debug views.
- M3 Shadows: stable, filtered, coloured; profile tiers; contact shadows.
- M4 Sky, atmosphere, fog, sunsets, night → FIDELITY CHECKPOINT 1 (rubric + user screenshots if available).
- M5 Water, translucents, underwater.
- M6 AO, SSS, emissive + bloom, colour-grade polish.
- M7 Clouds, volumetric light, rain/wetness.
- M8 Nether/End, entities/hand/particles/special states → FIDELITY CHECKPOINT 2.
- M9 Profile tuning, performance measurement, soak/stability.
- M10 Packaging, README, final verification, final report.

Exit criteria for every milestone: loads in Iris without errors (L2), lints pass, evidence logged, state files
updated, committed and tagged. If an effect breaks loading, hide it behind a disabled option until fixed.

---

## 13. DEBUGGING PLAYBOOK

- Read `logs/latest.log` first: Iris reports the failing program/stage and line numbers (relative to the
  processed source — see the Debugging Shaders and Iris Patcher docs).
- Bisect: disable programs via the program-enable directive, then effects via options, then use debug views.
- Frequent causes: wrong uniform type/name; varying mismatch between `.vsh`/`.fsh`; missing render-target
  declaration; clearing a history buffer; reading and writing the same buffer in one pass; exceeding
  MAX_COLOR_BUFFERS or sampler limits; `#include` path errors; option-syntax errors (`// [values]` comments)
  or options defined inconsistently across files; AMD strictness (implicit conversions, uninitialised
  values, int/float literals); non-constant loop bounds; NaNs from `normalize(0)`/division/`pow` of
  negatives (symptom: black/white flicker through bloom/TAA); precision loss from raw `frameTimeCounter` or
  huge world coordinates (wrap time, use camera-relative positions); depth-convention errors; sun/moon vector
  sign errors; forgetting that vertex colour carries biome tint and AO.
- Check the Iris issue tracker before spending hours on a suspected Iris/26.3 bug. If confirmed, add a
  pack-side workaround only when cheap; otherwise log it in KNOWN_ISSUES.md with the issue link.
- Fix root causes; do not paper over with clamps that hide real errors. Add a regression note to TEST_LOG.md.

---

## 14. DEFINITION OF DONE AND FINAL REPORT

Done means all of:
- The pack loads from the final ZIP on 26.3 with the pinned Iris/Sodium stack (OpenGL) on the target GPU with
  zero errors (L2) for all profiles and dimensions — or, if the game could not be run, everything is clearly
  marked NOT VERIFIED and the manual protocol ships.
- Every §6.2 item is IMPLEMENTED, or honestly APPROXIMATION / NOT FEASIBLE, in FEATURE_MATRIX.md with evidence
  levels. No core effect is a stub; no fake settings; no missing files; no unknown uniforms.
- Low/Balanced/High exist, are measured (L4), and Balanced is the default.
- ZIP, README, LICENSE and docs are complete; repo clean; milestones tagged.

Final report (write `docs/FINAL_REPORT.md` and paste it in chat):
1. Five-line summary. 2. Exact stack tested (Minecraft, Java, loader, Iris, Sodium, driver, OS). 3. What
works at each evidence level. 4. Feature-matrix highlights (implemented / approximation / not feasible / not
done). 5. Fidelity rubric scores and what still differs from Bedrock VV. 6. Performance table with method and
caveats. 7. Known issues, limitations, untested areas. 8. ZIP location + install steps. 9. Recommended next
steps (including the Vulkan-era outlook).
Never claim more than your evidence supports.

---

## 15. START NOW

1. Save this brief to `docs/MASTER_PROMPT.md`.  2. Workspace audit.  3. Capability/environment audit.
4. Resolve versions and build the isolated test instance (OpenGL).  5. Read the Iris docs/source → write the
allowlist.  6. Trivial pack from folder and ZIP; run the probes.  7. Reference research.  8. Gate decision →
M1.  Then proceed milestone by milestone without waiting for approval, committing and logging as you go.