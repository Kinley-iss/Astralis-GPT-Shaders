# Test log

## 2026-10-16 — Quality-only screen-space ray tracing

- Added composite-pass screen-space reflection rays against opaque `depthtex1` and
  two deterministic diffuse rays for a restrained one-bounce indirect-light
  approximation. Performance and Balanced explicitly disable both controls;
  Quality enables 12 ray steps and 0.08 indirect-light strength.
- Updated the pass/buffer/feature documentation to distinguish these visible-buffer
  approximations from full scene ray tracing or path tracing.
- `python tools\check_all.py`: PASS, including profile option wiring and ensuring
  ray tracing stays disabled in Performance/Balanced.
- `glslangValidator`: PASS for all 20 GLSL stages, the default composite variant,
  and the Quality tracing variant.
- `python tools\build_zip.py`: PASS. Archive rebuilt and inspected at
  `dist\Astralis_GPT_0.1.0.zip`.
- Iris live compile/link, depth behavior, visual quality, and GPU cost: NOT VERIFIED.

## 2026-10-16 — Performance, Balanced, and Quality profiles

- Replaced the previous Low/High profile entries with three clear presets: Performance,
  Balanced, and Quality. Quality uses a 2048 shadow map, 112-block range, 9-tap soft
  filtering, and finer water reflection cells; Performance disables optional screen-space
  costs and uses a compact shadow map.
- Added profile labels and descriptions and documented the Iris menu path. No default
  keyboard shortcut is provided by Iris.
- Declared `shadowMapResolution` and `shadowDistance` as GLSL constants in
  `lib/shadow_config.glsl`; profile changes now configure those constants rather than
  referencing undeclared shader identifiers.
- `python tools\check_all.py`: PASS. Three profile definitions and their option values match.
- `glslangValidator`: PASS. All 20 GLSL stages compile syntactically with the declared constants.
- `python tools\build_zip.py`: PASS. ZIP integrity and key source parity verified.
- Iris in-game profile switching and actual GPU/shadow behavior: NOT RUN / NOT VERIFIED.

## 2026-10-16 — Bound per-fragment celestial illumination

- GPU lighting evaluates the surface normal against Iris's celestial light direction,
  then multiplies direct illumination by shadow-map visibility and sky-light exposure.
- Added a shared 0.06 minimum illumination floor and 1.0 maximum per color channel to
  terrain/entity/water lighting and the textured-lit fallback so dark regions retain a
  little light and bright regions cannot exceed the bound.
- Corrected `shadowMapResolution` and `shadowDistance` usage: Iris injects these as
  compile-time constants declared in GLSL; declaring them only in `shaders.properties`
  or as uniforms does not create the GLSL identifiers.
- This is directional shadow-mapped lighting, not path-traced multi-bounce light.
- `python tools\check_all.py`: PASS. Three preset profile values match their GLSL defaults.
- `glslangValidator`: PASS. All 20 GLSL stages compile syntactically with the declared constants.
- `python tools\build_zip.py`: PASS. ZIP integrity and light-bound source parity verified.
- In-game light/shadow range and appearance: NOT RUN / NOT VERIFIED.

## 2026-10-16 — Blue moonlit night grade

- Reviewed Microsoft's official Vibrant Visuals overview, lighting and atmosphere
  documentation as references for separate sun/moon contributions and time-of-day grading.
- Replaced the grayscale-heavy night grade with a restrained cool blue tint that keeps
  surface colors recognizable, and applied a matching low-strength tint to the vanilla sky.
- Added a separate modest moon directional-light term gated by nighttime and the vanilla
  sky lightmap, preserving a substantially lower contribution than daytime sun.
- `python tools\check_all.py`: PASS. Nine program pairs and options validated.
- `glslangValidator`: PASS. All 20 GLSL stages passed syntax validation.
- `python tools\build_zip.py`: PASS. ZIP integrity and updated source parity verified.
- Nighttime appearance and moon/shadow orientation: NOT RUN / NOT VERIFIED in game.

## 2026-10-16 — Preserve entity hurt tint

- Applied Iris's documented `entityColor` tint (`rgb` plus alpha blend factor) after
  lighting, atmospheric grading, underwater tint, and fog in `gbuffers_entities`.
  This keeps vanilla damage red overlays visible instead of allowing the lighting grade
  to darken or desaturate them.
- `python tools\check_all.py`: PASS. Nine program pairs and settings/profile wiring.
- `glslangValidator`: PASS. All 20 shader stages passed syntax validation.
- `python tools\build_zip.py`: PASS. ZIP integrity and source parity verified.
- In-game mob damage flash: NOT RUN / NOT VERIFIED.

## 2026-10-16 — Enable Iris sun-shadow map and strengthen direct light

- Root cause found: profiles only changed custom shader constants for shadow resolution
  and distance; `shaders.properties` never configured Iris's actual `shadowMapResolution`,
  so the shadow depth pass was not explicitly enabled/configured.
- Switched shadow sampling to Iris's `shadowMapResolution` and `shadowDistance` uniforms,
  set actual defaults and profile values, and exposed those settings in the quality menu.
- Increased directional sun-vs-ambient contrast so shadow visibility affects a more
  substantial part of the surface illumination.
- `python tools\check_all.py`: PASS. Nine program pairs and shadow settings/profile wiring.
- `glslangValidator`: PASS. All 20 GLSL stages passed syntax validation.
- `python tools\build_zip.py`: PASS. Archive integrity and shadow settings presence verified.
- Runtime shadow coverage and orientation: NOT RUN / NOT VERIFIED.

## 2026-10-16 — Color saturation and night color preservation

- Increased final saturation to 1.16 and removed the below-neutral vibrance reduction
  in dark pixels, which had contributed to the subdued/greyscale appearance.
- Reduced the night-grade grayscale blend from 50% to 24% while retaining a cool night tint.
- Solas Shader V3.5 sources were not transplanted: its archive contains a notice identifying
  its code as the creator's work, and the shader pipeline/interfaces differ from this pack.
- `python tools\check_all.py`, GLSL validation, ZIP rebuild: NOT RUN YET.
- In-game color balance: NOT RUN / NOT VERIFIED.

## 2026-10-15 — Sun-aligned pixel-cell water reflections

- Replaced the water shader's tile-center-distance sun highlight with a reflected ray
  calculated from view position and normal interpolated to each screen-cell center.
- Use the reflected ray's elevation for sky/horizon color and its alignment with Iris's
  celestial light direction for the reflected sun disk. Removed artificial cell-edge glints.
- Reflection remains analytic and does not sample reflected terrain or structures; live
  Iris appearance and performance still require in-game validation.
- `python tools\check_all.py`: PASS. Nine GLSL program pairs and the shadow pass validated.
- `glslangValidator`: PASS. All 20 shader stages passed syntax validation after include expansion.
- `python tools\build_zip.py`: PASS. Rebuilt and inspected `dist\Astralis_GPT_0.1.0.zip`.
- Iris compile/link, in-game appearance, and GPU performance: NOT RUN / NOT VERIFIED.

## 2026-10-11 — Local static checks and ZIP inspection

- `python tools\check_all.py`: PASS. Eight G-buffer/composite/final program pairs and
  the shadow pair; source pair presence, `main` entry points, include existence and
  cycles, fragment-varying name/type checks, settings screen references, option
  labels/tooltips, profile option coverage, Balanced-default parity, slider options,
  profile values, and settings option code usage are checked.
- GLSL compile/link: NOT RUN. `glslangValidator` was not found on PATH; checker is
  not a parser/compiler.
- `python tools\build_zip.py`: PASS. Built deterministic ZIP and confirmed root
  `shaders/`, README, LICENSE, shadow/composite/final code and localized options;
  confirmed archive paths use forward slashes.
- Repeated build produced the same SHA-256:
  `4C517A0533C3E7A02D738D26DE5668585522B2C8C479FBF668A04D779EA9A286`.
- In-game folder load / ZIP load: NOT RUN.
- Scenario, stability, reload, resize, profile-toggle tests: NOT RUN.
- Result: L1 limited static checks only; L2/L3/L4 remain NOT VERIFIED.

## 2026-10-11 — Enhanced atmospheric grading and underwater filter

- Added `astralisAtmosphericGrade()`: per-channel twilight warmth (higher red, moderate green, lower blue), night desaturation with cool tint, and rain dampening across all passes (terrain/entities/water).
- Added `astralisUnderwaterFilter()` using Iris `isEyeInWater` uniform: restrained cyan tint when submerged.
- Improved final.fsh color grade: added luminance-adaptive vibrance and normalized contrast calculation.
- Updated all major G-buffer passes (terrain, entities, water) to use the new grading functions in sequence: illumination → atmospheric grade → underwater filter → fog.
- `python tools\check_all.py`: PASS. Static structure, entry points, includes, and fragment varying names validated.
- `python tools\build_zip.py`: PASS. Rebuilt deterministic ZIP with updated shader sources.
- ZIP integrity: PASS. All changed shaders present and content-verified. SHA-256:
  `68D202F015D8A118D8440D4870CA9C4537680489E784FBF2C3E5ECEA98E148E2`.
- Updated feature matrix: twilight/night grading, underwater filter, and vibrance-adaptive final grading added.
- In-game Iris compile/link, appearance validation, End flash and underwater-state behavior:
  NOT RUN / NOT VERIFIED.
- Result: L1 static and archive checks pass; L2/L3/L4 remain NOT VERIFIED.

## 2026-10-12 — Pixelated water reflections

- Added adjustable screen-cell normal perturbation to the analytic Fresnel sky reflection,
  plus quantized GPU-computed sun glints to produce the blocky reflection appearance.
- Added `WATER_PIXEL_SIZE` choices (1, 2, 3, 4, 6 px); Low/Balanced/High select 4/3/2 px.
- This remains a stylized analytic reflection and does not sample reflected scene geometry
  or implement screen-space reflections (SSR).
- `python tools\check_all.py`: PASS. Eight GLSL program pairs and shadow pass,
  including shader option and profile consistency.
- `python tools\build_zip.py`: PASS. ZIP built and inspected; updated water shader,
  settings, and localization are present. Archive content check: PASS.
- ZIP SHA-256: `dbeaa4c02bb870064945b6567106557b62f0e0f5d755290346c9c35096665d7b`.
- Iris compile/link, in-game visual appearance, and performance: NOT RUN / NOT VERIFIED.

## 2026-10-12 — Brighter pixelated sun path

- Increased water-reflection cell-size range to 2-12 screen pixels; Balanced now defaults
  to 6 px so the segmentation is more visible at typical display resolutions.
- Broadened and brightened the GPU-computed sun glint, added per-cell sparkle variation,
  and added a small analytically reflected sun disk to the sky reflection.
- `python tools\check_all.py`: PASS. Eight GLSL program pairs and shadow pass, with
  reflection size, localization, and profile coverage checks.
- `python tools\build_zip.py`: PASS. ZIP rebuilt and inspected; SHA-256:
  `3e8b7a15d5afd7cbeabb1f59114200f26dcb351ccf3cd9cb8627305e6d095306`.
- Iris compile/link, in-game visual appearance, and performance: NOT RUN / NOT VERIFIED.

## 2026-10-12 — Pixelated player and block shadows

- Added `SHADOW_PIXEL_SIZE` to snap shadow-map lookup coordinates to a selectable
  1/2/4/8-texel grid; sizes above 1 use a single depth comparison for hard edges.
- Low/Balanced/High profiles use 8/4/2 shadow-map texels per shadow step.
- Pixelated player shadows require player geometry to be submitted to Iris's shadow
  pass and the game's entity-shadow setting to be enabled.
- `python tools\check_all.py`: PASS. Eight GLSL program pairs and shadow pass,
  including the new shadow-pixel-size option and profile consistency.
- `python tools\build_zip.py`: PASS. ZIP built and inspected; SHA-256:
  `762f5668d89ba188a149398b5e786fa7a0d10d2a933aa397140e2a9f426e7ed9`.
- Iris compile/link and in-game player-shadow verification: NOT RUN / NOT VERIFIED.

## 2026-10-12 — Brighter sun and block lighting

- Added a dedicated `gbuffers_skytextured` shader to brighten the vanilla sun/moon sprites,
  warm the daytime sun, and cool-tint the moon.
- Increased block-lightmap contribution by up to 65% in terrain, entities, translucent
  terrain, and lit particles while preserving the lightmap's existing color.
- Exact Bedrock RGB per-source colors cannot be reproduced from the Java lightmap alone;
  source-block identity is unavailable in these shader inputs.
- `python tools\check_all.py`: PASS. Nine GLSL program pairs and shadow pass,
  including the dedicated sky-textured pass and existing settings checks.
- `python tools\build_zip.py`: PASS. Archive contains the new celestial shader and
  updated lighting code; SHA-256:
  `4c8ac93fe29b86a5f124efcb862d69f34b60954da2c9315e8330fed179bd7463`.
- Iris compile/link, appearance, and GPU performance: NOT RUN / NOT VERIFIED.

## 2026-10-12 — Performance Boost profile

- Added a Performance Boost profile: 256 shadow resolution, 32-block shadow distance,
  one depth tap, 8-texel hard shadows, and compile-time disabled contact AO, water
  reflections and bloom.
- Moved water-reflection-only cell noise, view-direction and perturbed-normal work
  behind the `WATER_REFLECTION` preprocessor guard, removing those instructions when
  the Performance Boost profile disables reflections.
- FPS/frame-time improvement: NOT MEASURED; reduced shader workload does not guarantee
  a specific uplift on a particular GPU or scene.
- `python tools\check_all.py`: PASS. Nine GLSL program pairs and shadow pass, including
  profile option coverage and Balanced-default consistency.
- `python tools\build_zip.py`: PASS. Archive built with the Performance Boost settings;
  SHA-256: `06852d61fdcd74f91c80320a79fe5ecfab7622d396e8ea89a4afc69086532dcf`.
- Iris compilation and profile selection: NOT RUN / NOT VERIFIED.
