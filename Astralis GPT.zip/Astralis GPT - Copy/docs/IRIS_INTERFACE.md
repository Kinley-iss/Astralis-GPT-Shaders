# Iris interface allowlist

This starter uses the compatibility GLSL interface described by the current Iris
DocsPage. Documentation sources were retrieved on 2026-10-10. Current docs/source
are not proof that a specific Iris build for Minecraft 26.3 accepts this pack;
in-game load and compile remain NOT VERIFIED.

## Programs

| Name | Use | Primary source |
| --- | --- | --- |
| `gbuffers_terrain` | Static blocks | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_entities` | Entities and name-tag text fallback coverage | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_textured` | Textured geometry and fallback for several render programs | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_water` | Translucent terrain, including water | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_textured_lit` | Lit particles | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_skybasic` | Sky color/horizon, stars, void | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `gbuffers_skytextured` | Sun and moon textures | [Iris gbuffers program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/gbuffers.mdx) |
| `shadow` | Directional-light depth map | [Iris shadow program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/shadow.mdx) |
| `composite` | Bloom into `colortex3` | [Iris composite program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/composite.mdx) |
| `final` | Display grade from `colortex3` | [Iris final program reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Programs/final.mdx) |

## Used compatibility attributes and built-ins

| Name | Type / meaning | Primary source |
| --- | --- | --- |
| `gl_MultiTexCoord0` | Built-in vec4 vertex texture coordinate | [Iris attribute reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Attributes/gl_MultiTexCoord0.mdx) |
| `gl_MultiTexCoord1` | Built-in vec4 block/sky lightmap coordinate | [Iris attribute reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Attributes/gl_MultiTexCoord1.mdx) |
| `gl_Color` | Built-in vec4 vertex tint (can carry biome tint and AO) | [Iris attribute reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Attributes/gl_Color.mdx) |
| `ftransform()` | Built-in clip-space transform in compatibility shaders | [Iris attribute reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Attributes/ftransform.mdx) |
| `gl_TextureMatrix[0]` | Built-in texture UV transform | [Iris matrix reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/matrices.mdx) |
| `gl_TextureMatrix[1]` | Built-in lightmap UV transform | [Iris matrix reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/matrices.mdx) |
| `gl_Normal` / `gl_NormalMatrix` | Built-in model normal and model-to-view normal matrix | [Iris matrix reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/matrices.mdx) |

## Samplers

| Name | GLSL type | Binding evidence |
| --- | --- | --- |
| `texture` | `sampler2D` | Main texture sampler alias; Iris source resolves `Sampler0` to `texture` after trying `tex` and `gtexture`. [Iris MixinUniform.java](https://github.com/IrisShaders/Iris/blob/bff1e69cb6c5519d8745784aa9c8b92984de67e7/common/src/main/java/net/irisshaders/iris/mixin/MixinUniform.java) |
| `lightmap` | `sampler2D` | Iris source resolves `Sampler2` to `lightmap`. [Iris MixinUniform.java](https://github.com/IrisShaders/Iris/blob/bff1e69cb6c5519d8745784aa9c8b92984de67e7/common/src/main/java/net/irisshaders/iris/mixin/MixinUniform.java) |
| `shadowtex0` | `sampler2D` | Depth sampler including all shadow-pass geometry. [Iris ShadowTex reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Buffers/shadowtex.mdx) |
| `colortex0`, `colortex3` | `sampler2D` | Color attachment samplers, used only by composite/final stages here. [Iris ColorTex reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Buffers/colortex.mdx) |
| `depthtex0` | `sampler2D` | Depth sampler including opaque and translucent geometry, sampled in composite. [Iris DepthTex reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Buffers/depthtex.mdx) |

## Used uniforms and constants

| Name | Type | Use / primary source |
| --- | --- | --- |
| `gbufferModelViewInverse`, `shadowModelView`, `shadowProjection` | `mat4` | Transform geometry into shadow clip space. [Matrix reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/matrices.mdx) |
| `shadowLightPosition` | `vec3` | Direction of highest celestial body and shadow caster in view space. [World uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx) |
| `sunAngle` | `float` | Celestial phase (0 sunrise, 0.25 noon, 0.5 sunset, 0.75 midnight), used for sun/moon tint. [World uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx) |
| `rainStrength` | `float` | Rain grading. [World uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx) |
| `isEyeInWater` | `int` | Iris immersion state; tested as zero/non-zero before applying the underwater tint. |
| `entityColor` | `vec4` | Iris entity tint (`rgb` plus blend alpha), applied after lighting and fog to preserve hurt flashes and other vanilla entity overlays. [Rendering uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/rendering.mdx) |
| `endFlashPosition` | `vec3` | Iris-exclusive End-flash position in view space, used for a low-strength directional response. [World uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx) |
| `endFlashIntensity` | `float` | Iris-exclusive End-flash intensity, used for a bounded directional response and water reflection tint. [World uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx) |
| `fogColor` | `vec3` | Biome/weather-provided fog color. [Rendering uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/rendering.mdx) |
| `skyColor` | `vec3` | Analytic water reflection fallback. [Rendering uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/rendering.mdx) |
| `fogStart`, `fogEnd` | `float` | Approximate linear aerial fog. [Rendering uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/rendering.mdx) |
| `viewWidth`, `viewHeight` | `float` | Pixel offsets for low-tap bloom. [System uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/system.mdx) |
| `gbufferProjectionInverse` | `mat4` | Reconstruct view-space depth positions for contact occlusion. [Matrix reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/matrices.mdx) |
| `alphaTestRef` | `float` | Shadow-map cutout threshold. [Rendering uniform reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/rendering.mdx) |
| `shadowMapResolution` | `const int` | GLSL compile-time constant that configures the Iris shadow buffer; declared in `lib/shadow_config.glsl` and overridden by profile values. [Iris constant reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Constants/shadowMapResolution.mdx) |
| `shadowDistance` | `const float` | GLSL compile-time constant that configures the Iris shadow radius; declared in `lib/shadow_config.glsl` and overridden by profile values. [Iris constant reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Constants/shadowDistance.mdx) |

The include syntax `#include "/lib/name.glsl"` is documented by Iris:
[include reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Miscellaneous/include.mdx).
The composite output directive `/* RENDERTARGETS: 3 */` is documented here:
[RENDERTARGETS reference](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Constants/rendertargets.mdx).
Option, screen, slider, and profile syntax follows the Iris shader settings reference:
[Shader Pack Settings](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Shaders.Properties/shader_settings.mdx).

## Shader language and unsupported surface

- GLSL `#version 120` compatibility syntax is used. Iris recommends the compatibility
  profile for legacy built-in attributes in modern Minecraft versions:
  [compatibility vs. core](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/How%20To/compatibility_vs_core.mdx).
- User options are defined as GLSL preprocessor macros and consumed in the matching
  programs; the Low/Balanced/High profiles match those macro defaults/settings.
  Runtime persistence/UI validation remains unverified. Shader source declares only
  documented Iris-provided uniforms (including the Iris-exclusive End-flash values);
  it adds no user-defined uniforms, custom images, or compute shaders. Composite
  writes `colortex3`; final reads it.
- Sampler bindings are evidenced from Iris source, but still require target-version
  empirical compilation.
