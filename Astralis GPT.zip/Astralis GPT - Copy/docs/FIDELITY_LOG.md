# Fidelity log

No in-game images are available. All visual scores are **unassessed — needs user
review**; no Bedrock match is claimed.

| Axis | Score | Notes |
| --- | --- | --- |
| Sun/moon color and direction | Unassessed | Shadow and light direction need full-day validation. |
| Shadow quality/tint | Unassessed | Single depth shadow map; no colored shadows. |
| Sky, sunsets, stars, clouds | Unassessed | Subtle tint only; vanilla clouds retained. |
| Fog and volumetrics | Unassessed | Uses linear vanilla fog uniforms; no shafts. |
| Water | Unassessed | Analytic sky reflection only; no SSR/refraction. |
| Foliage/emissives/bloom | Unassessed | Heuristic foliage and low-strength bloom; emissive isolation absent. |
| Color/contrast and pixel integrity | Unassessed | Conservative grade; screenshot comparison required. |

