# Known issues

- Not compiled or loaded in Iris. Any GLSL interface, output routing, or blending
  incompatibility is still possible.
- Shader shadows now request an Iris shadow map through `shadowMapResolution` and
  configure its distance in each profile. Sun/moon orientation, reversed depth,
  lightmap behavior, bias acne/peter-panning, cutout leaves, and actual runtime
  coverage still require an in-game validation pass.
- Per-fragment directional lighting is shadow-map occluded and bounded to a subtle
  0.06 minimum and 1.0 maximum. This is not ray-traced multi-bounce global illumination;
  the bound is a simple artistic fill/ceiling.
- Sun/moon color is a small `sunAngle`-based tint over vanilla lighting, not
  physically calibrated illumination. End-flash lighting is unshadowed and depends
  on Iris-exclusive uniforms; its target-version behavior is unverified.
- The fixed 1024 shadow map and four taps may be too costly or too soft/shimmering;
  no GPU timing exists. The observed system adapter is Vega 3, not Vega 8.
- Fog applies a linear `fogStart`/`fogEnd` approximation. Iris exposes fog mode/shape
  and immersion states that are not implemented in this build.
- The water shader retains its analytic sky reflection as a fallback. Quality's
  composite pass adds bounded screen-space reflection and two-ray, one-bounce
  diffuse gathering from opaque visible buffers. These are not full ray/path tracing:
  off-screen and occluded geometry is unavailable, hit misses are expected, and
  depth-derived normals can fail at silhouettes. There is still no refraction,
  depth absorption, animated normal, or temporal accumulation.
- Quality screen-space ray marching adds depth/color texture reads per pixel on
  water and opaque surfaces. Its GPU cost and visual stability have not been measured.
- Green-channel heuristics can identify non-foliage materials as foliage and miss
  red/orange/yellow leaves.
- Warm block-light tint is driven by the transformed lightmap U coordinate; its
  behavior must be checked on the actual stack because lightmap conventions vary.
- Bloom is a four-sample full-resolution pass and may cost more than its small
  visual contribution justifies on low-end GPUs.
- The AO mode is a low-tap depth-edge contact approximation, not hemisphere-sampled
  AO; it can produce halos and needs depth-convention validation.
- No volumetrics, procedural clouds, material/block mapping, colored shadows, or
  dedicated Nether/End tuning.
