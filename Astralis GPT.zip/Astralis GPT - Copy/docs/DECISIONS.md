# Decisions

## 2026-10-10 — Product and location

- Context: The supplied brief names JVV and prohibits edits to the existing `.minecraft` installation, while the user requested the name Astralis GPT and explicitly authorized a project folder in `shaderpacks`.
- Choice: Use the product/folder name `Astralis GPT`, create a new sibling project directory, and leave all existing shaderpacks and game configuration untouched.
- Evidence: User confirmation in the conversation.

## 2026-10-10 — Starter scope

- Context: Iris program APIs and target game compatibility have not been empirically verified.
- Options: Add advanced effects using assumed uniforms/programs, or keep a restrained pass-through starter until the interface is confirmed.
- Choice: Use basic GLSL 1.20 built-ins, texture/lightmap sampling, and a subtle colour adjustment; do not claim shadows/reflections/volumetrics or invent Iris configuration keys.
- Trade-off: Low fidelity and incomplete feature coverage in exchange for a smaller, auditable initial shader surface.

## 2026-10-10 — Runtime evidence

- Choice: Mark all Iris/game/GPU runtime claims NOT VERIFIED until directly tested on the intended stack; ship a manual test protocol for outstanding checks.

## 2026-10-11 — Broad VV feature pass

- Context: The user asked to implement broadly what Bedrock Vibrant Visuals offers. Iris has documented compatibility programs, shadow buffers, world/fog uniforms, and color attachments, but no target game session or GL compiler is available.
- Choice: Implement a cautious source-level approximation for a single directional shadow map, normal/lightmap lighting, weather-aware fog, low-sun tint, foliage backlight heuristic, analytic Fresnel water reflection, low-tap bloom, and final grade. Use `colortex0` to `colortex3` to avoid same-pass feedback. Keep AO/SSR/refraction/volumetrics/PBR materials/profiles out until depth, interfaces, and performance can be tested.
- Evidence: Current Iris DocsPage program, buffer, uniform, constant, and include references; see `docs/IRIS_INTERFACE.md`.
- Trade-off: Broader visual coverage now, but still no L2 compile/link evidence and no claim of matching Bedrock VV. Effect costs and quality remain unmeasured.
