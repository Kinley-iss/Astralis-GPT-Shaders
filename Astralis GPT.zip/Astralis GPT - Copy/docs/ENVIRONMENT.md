# Environment

Collected 2026-10-11 using the available PowerShell tools.

| Item | Observation |
| --- | --- |
| OS | Windows; detailed OS build not captured. |
| Java on PATH | Oracle Java 27, build 27+35-2325. The Minecraft launcher can bundle/use a different runtime. |
| Display adapter | AMD Radeon(TM) Vega 3 Graphics. |
| Display driver | 31.0.21925.1001. |
| Reported adapter RAM field | 2147483648 bytes; this field is not a measurement of available shared system memory. |
| Target from supplied brief | Ryzen 3 3200G / Radeon Vega 8 / 16 GB dual-channel DDR4. Not the observed adapter. |
| OpenGL / GLSL strings | Not queried: no running GL context. |
| RAM speed/channels | Not queried. |
| Minecraft / loader / Iris / Sodium | Read-only files indicate Minecraft 26.3, Fabric Loader 0.19.5, Iris 1.11.7, and Sodium 0.9.2 are installed. No instance was launched for this task. |
| Available validation | PowerShell, Python, Java runtime, file access, internet documentation access. No `glslangValidator` was found on PATH when checked. |
| GUI/game capture | No in-game launch or screenshot capture was performed. |

No system-wide setting, Minecraft profile, save, or existing shader-pack was changed.
