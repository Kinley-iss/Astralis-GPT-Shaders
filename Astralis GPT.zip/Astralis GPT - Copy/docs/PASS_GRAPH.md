# Pass graph

1. **Shadow** — `shadow.vsh/fsh` renders textured geometry to Iris `shadowtex0`;
   alpha below Iris `alphaTestRef` is discarded. Balanced defaults are 1024 pixels,
   80 blocks, and four depth comparisons; the settings profiles alter these.
2. **Opaque G-buffers** — `gbuffers_terrain` and `gbuffers_entities` preserve the
   texture/lightmap inputs, compute a small sun/moon normal term, sample 4-tap shadow
   visibility, apply low-sun/rain/block-light grading, and fade to Iris fog color.
3. **Translucent terrain** — `gbuffers_water` uses the same directional/shadow
   approximation, plus a Fresnel-weighted analytic sky/horizon reflection. The
   reflected view direction is evaluated at configurable screen-cell centers, and
   the sun disk follows its alignment with Iris's active light direction. It does
   not sample the scene/depth or refract it.
4. **Other geometry** — `gbuffers_textured_lit` multiplies texture and vertex tint
   by the brightened vanilla block lightmap. `gbuffers_textured` passes texture and
   vertex color through.
5. **Sky** — `gbuffers_skybasic` gently warms the existing sky vertex color at
   low-sun angles and desaturates it slightly in rain; `gbuffers_skytextured`
   brightens and tints the vanilla sun/moon sprites.
6. **Composite** — one `composite` pass reconstructs view-space depth with four/eight
   taps for optional contact darkening, samples bright sky pixels toward the projected
   sun for optional screen-space shafts, and samples four neighboring points from
   `colortex0` for optional thresholded bloom. Quality additionally marches reflection
   and two diffuse rays against opaque `depthtex1`, sampling hit color from `colortex0`.
   Performance and Balanced set those trace controls to zero. The result is written to
   `colortex3`.
7. **Final** — `final` applies subtle saturation/contrast and writes `colortex3` to
   the backbuffer.

The screen-space traces are bounded approximations: they cannot see off-screen or
occluded geometry, and the diffuse pass is one screen-space bounce rather than full
path tracing. Program ordering, attachment routing, and pass compilation still require
Iris runtime verification.
