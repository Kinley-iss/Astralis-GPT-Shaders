# Compatibility matrix

Evidence is limited to current published documentation/source inspection. The
Minecraft 26.3 stack and the pack have **not** been loaded in-game.

| Component | Target | Observed/verified | Status |
| --- | --- | --- | --- |
| Minecraft Java | 26.3 | Existing read-only version directory `versions\26.3` is present. No dedicated instance was launched. | Installed files observed; pack compatibility NOT VERIFIED |
| Java | Launcher-provided runtime | System `java -version` reports Oracle Java 27, build 27+35-2325. This does not establish the runtime used by Minecraft. | Observed; target not verified |
| Loader | Fabric | Existing version directory `iris-fabric-loader-0.19.5-26.3` inherits `26.3`; JSON main class is Fabric KnotClient. | Installed files observed; pack compatibility NOT VERIFIED |
| Fabric API | Exact compatible release | Not inspected. | NOT VERIFIED |
| Sodium | Exact compatible release | Existing `sodium-fabric-0.9.2+mc26.3.jar` observed in `.minecraft\mods`. | Installed filename observed; pack compatibility NOT VERIFIED |
| Iris | Exact compatible release | Existing `iris-fabric-1.11.7+mc26.3.jar` observed in `.minecraft\mods`; official DocsPage current branch and Iris source reviewed. | Installed filename observed; pack compatibility NOT VERIFIED |
| OpenGL / GLSL | OpenGL compatibility profile | No live GL context or shader compiler was queried. | NOT VERIFIED |
| Graphics card | Vega 8 target | Windows reports AMD Radeon(TM) Vega 3 Graphics, driver 31.0.21925.1001, AdapterRAM field 2147483648. Not the requested Vega 8 target. | Observed machine differs from target |
| Iris folder load | Astralis GPT | Not launched. | NOT VERIFIED |
| ZIP load | Astralis_GPT_0.1.0.zip | Archive structure inspected only. | NOT VERIFIED |

## Primary references consulted (retrieved 2026-10-11)

- Iris shader interface docs: https://github.com/IrisShaders/DocsPage/tree/main/src/content/docs/current
- Iris source sampler aliases: https://github.com/IrisShaders/Iris/blob/bff1e69cb6c5519d8745784aa9c8b92984de67e7/common/src/main/java/net/irisshaders/iris/mixin/MixinUniform.java
- Microsoft Bedrock Vibrant Visuals lighting documentation:
  https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/lightingcustomization?view=minecraft-bedrock-stable

The local install appears to contain the prompt's target release family, but this is
not evidence that the pack compiles or that these JARs match official hashes.
Fabric API presence and hashes, exact loader release provenance, and target OpenGL
strings remain unverified. No launcher/profile or mod was changed.
