# Progress

## Current state

An expanded source-level VV approximation is present: one directional shadow map,
normal/lightmap lighting, fog and time/weather grading, analytic water reflection,
thresholded bloom, final grade, and wired Low/Balanced/High options. Current local
files include Minecraft 26.3, Fabric Loader 0.19.5, Iris 1.11.7, and Sodium 0.9.2,
but no game was launched and none of the shader interfaces has runtime validation.

## Milestone ledger

| Milestone | State | Evidence |
| --- | --- | --- |
| M0 Recon and feasibility | Partial / gate unverified | Existing files and local stack filenames inspected read-only; current Iris interface sources consulted; trivial pack not run in game. |
| M1 Minimal pack and tooling | Source complete; L2 unverified | Program pairs, options/profiles, static checker, and deterministic ZIP created. |
| M2 Lighting core | Partial / L2 unverified | Lightmap, normal, blocklight tint, day color, and fog approximation. |
| M3 Shadows | Partial / L2 unverified | Shadow map and 1/4/9-tap comparisons; no stability test. |
| M4 Sky/atmosphere | Partial / L2 unverified | Retained vanilla sky with low-sun tint; vanilla fog range used. |
| M5 Water | Partial / L2 unverified | Analytic Fresnel sky reflection and glint only. |
| M6 AO/emissive/post | Partial / L2 unverified | Low-tap depth-edge contact AO approximation, bloom and grade; no full GTAO or emissive extraction. |
| M7 Clouds/volumetrics | Not done | Vanilla clouds retained; no shafts or procedural clouds. |
| M8 Dimensions/special states | Not done | Not validated or tuned. |
| M9 Performance/fidelity | Not done | No game benchmark or visual captures. |
| M10 Packaging/docs | Static package built | ZIP structure inspected; no in-game ZIP load. |

## Next actions

1. Establish a disposable test instance using verified official release artifacts, keeping the existing installation untouched.
2. Compile/link the pack from both folder and ZIP; inspect `latest.log`.
3. Validate shadow matrix/depth conventions, lighting, options, and translucency in-game.
4. Tune/measure all profiles on the target Vega 8 hardware; observed machine adapter is Vega 3.
5. Implement depth-based AO/SSR, volumetrics, material/emissive mapping, clouds, and dimension-specific behavior only after runtime validation.

## Blockers

- The target Minecraft/Iris/Sodium files appear installed, but this shader pack has not been loaded or compiled in-game.
- No GLSL compiler was found on PATH; static checks are not GLSL parsing.
- Target Vega 8 runtime and performance evidence are unavailable.
