# Java 26.3 Vibrant Visuals look mapping

This pack targets **Minecraft Java 26.3 with Iris**, not Bedrock Edition. The
supplied Vibrant Visuals briefing describes Bedrock's RenderDragon pipeline and
its supported resource-pack JSON / PBR texture-set system. Those file formats,
biome bindings, and Script API do not configure a Java Iris shader pack, so this
project does not include a Bedrock `manifest.json`, Bedrock JSON settings, or
unsupported RenderDragon engine shaders.

Instead, the Bedrock description is used as a visual reference. Java effects below
use the documented Iris GLSL interface and retain vanilla Java textures, biome
tints, lightmap, and fog wherever this pack lacks equivalent material/world data.

| Bedrock VV concept | Java 26.3/Iris treatment | Boundary |
| --- | --- | --- |
| Bright sun and celestial sprites | `gbuffers_skytextured` brightens the vanilla sun/moon sprites and adds a warm daytime tint; existing bloom may create a soft halo. | Preserves vanilla sprite geometry and size; not a replacement for Bedrock's atmospheric sky rendering. |
| Orbital sun/moon light and pixelated shadows | Iris `shadowLightPosition` drives the directional term and the existing shadow map; `sunAngle` blends neutral/warm daytime and faint cool nighttime light. Shadow-map lookup snaps to a configurable texel grid for hard blocky silhouettes. | Single approximate shadow map; player silhouette depends on Iris rendering the player into the shadow pass and the game's entity-shadow setting; no physical lux or verified transition. |
| End flash | Iris `endFlashPosition` and `endFlashIntensity` add a restrained cool directional response on terrain/entities and a subtle water-reflection highlight. | No flash-specific shadow, exposure adaptation, or calibrated intensity. |
| Twilight and atmospheric color | Solar elevation drives per-channel twilight warmth (red boost, blue reduction) and night desaturation with cool tint. Rain dampens all tints. | Not physically-based Rayleigh/Mie or biome-specific; calibration is approximate. |
| Ambient, sky, and block light | Vanilla lightmap and vertex color/AO are preserved; block-light brightness is increased by up to 65% according to its lightmap coordinate. | The Java pass exposes the lightmap, not the identity of the emitting block; exact per-source Bedrock torch/redstone/soul/lantern/copper RGB assignment is unavailable. No independent local point-light buffer. |
| Atmospheric sky and fog | Vanilla sky remains; Iris fog color/range, low-sun tint, and rain desaturation provide the lightweight atmosphere approximation. | No Rayleigh/Mie scattering, volumetric fog/light shafts, procedural clouds, or custom biome atmosphere keyframes. |
| Water | Vanilla water texture/tint plus a Fresnel analytic sky reflection, reflected sun disk, broad segmented sun path with adjustable cell size, and underwater cyan filter (via `isEyeInWater`). | This stylized pixelation does not reflect nearby scene geometry; no particle-concentration absorption, image-based animated waves, caustics, depth-aware refraction, or screen-space reflections. |
| PBR surfaces and reflections | Vanilla texture/lightmap shading only. | Bedrock MERS texture sets, normal/height maps, roughness/metalness, subsurface, and screen/image-based PBR reflections have no per-block material table in this pack. |
| Biome customization and blending | Vanilla biome vertex tint and Iris-supplied fog continue to apply. | No Bedrock `client_biome` identifiers or per-biome configuration interpolation. |
| Color grading and tone mapping | Twilight/night per-channel tinting, rain desaturation, and final luminance-adaptive vibrance plus contrast. | No HDR auto-exposure, Bedrock grading JSON/API, per-channel tone curve controls, TAAU, or temporal history. |

## Implementation notes

- Celestial phase follows Iris `sunAngle`: sunrise `0`, noon `0.25`, sunset `0.5`,
  midnight `0.75`. The active celestial direction still comes from Iris's
  `shadowLightPosition`, which changes between sun and moon in the Overworld.
- A dedicated `gbuffers_skytextured` program boosts the vanilla sun/moon sprites
  and colors the daytime sun warmer than the moon.
- End-flash shading is intentionally low-strength and unshadowed. It does not add
  a new shader option or assume an undocumented properties key.
- Shadow lookup can snap to a 1/2/4/8-texel grid for blocky edges; setting the size
  to 1 restores the selected multi-tap soft filter. Player shadows still depend on
  the game/Iris submitting the player model to the shadow pass.
- Rain slightly softens the direct shadow term, while existing rain desaturation
  and Iris-provided fog remain in place.
- Water reflection uses a screen-space cell grid, perturbed normals, a reflected sun
  disk, and broad stepped sun-glint intensity for a visibly segmented sun path. This
  remains in the existing water pass and does not trace or sample reflected scene geometry.
- Java GLSL pass code, image-based water approximation, contact shading, and bloom
  are features of this Iris pack. They are not representations of Bedrock pack
  JSON fields or claims that those fields are editable in Bedrock.

## Verification

The source checker and ZIP builder can validate the pack's static structure and
archive. They cannot compile/link the GLSL or verify the appearance, End flash
behavior, compatibility, or frame time in Minecraft 26.3. Those remain
**NOT VERIFIED**; see [TEST_LOG.md](./TEST_LOG.md) and
[MANUAL_TEST_PROTOCOL.md](./MANUAL_TEST_PROTOCOL.md).

## References

- User-provided Bedrock VV technical briefing, especially its distinction between
  official resource-pack/Script API customization and unsupported engine-shader
  replacement.
- [Microsoft Learn: Vibrant Visuals overview](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/introvibrantvisuals?view=minecraft-bedrock-stable)
- [Microsoft Learn: Vibrant Visuals lighting](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/lightingcustomization?view=minecraft-bedrock-stable)
- [Microsoft Learn: Vibrant Visuals water](https://learn.microsoft.com/en-us/minecraft/creator/documents/vibrantvisuals/watercustomization?view=minecraft-bedrock-stable)
- [Iris world and weather uniforms](https://github.com/IrisShaders/DocsPage/blob/main/src/content/docs/current/Reference/Uniforms/world.mdx), including `sunAngle`, `shadowLightPosition`, `endFlashPosition`, and `endFlashIntensity`.
