# Performance log

No FPS or frame-time measurement has been taken. The observed adapter is Vega 3,
not the brief's target Vega 8; high-tap shadows/contact AO and full-resolution bloom
may be costly.

| Scene | Profile | Setting | Frame-time delta | Notes |
| --- | --- | --- | --- | --- |
| — | — | — | NOT MEASURED | No game session was launched. |
