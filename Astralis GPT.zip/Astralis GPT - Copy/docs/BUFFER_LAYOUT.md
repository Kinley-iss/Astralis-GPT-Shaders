# Buffer layout

No custom G-buffer attachments are declared.

| Buffer | Resolution/format | Producer | Consumer | Lifetime / notes |
| --- | --- | --- | --- | --- |
| `shadowtex0` | Iris `shadowMapResolution`; Balanced 1024, Performance 256 | `shadow` depth pass, enabled by the Iris shadow-map setting | `gbuffers_terrain`, `gbuffers_entities`, `gbuffers_water` | Iris-owned depth buffer; resolution and distance are set by shader-pack defaults/profiles. |
| `colortex0` | Default Iris display-sized color attachment/format | Default opaque/translucent G-buffer outputs | `composite` bloom pass | Assumed conventional Iris output; must confirm at runtime. |
| `colortex3` | Default Iris display-sized color attachment/format | `composite` via `RENDERTARGETS: 3` | `final` | Separate source and destination avoid same-pass feedback. |
| `depthtex0` | Display-sized depth including translucent geometry | Iris geometry pass | `composite` | Used for contact occlusion and to identify a nearer translucent surface in the Quality-only screen-space reflection approximation. |
| `depthtex1` | Display-sized opaque-only depth | Iris geometry pass | `composite` | Used by Quality-only screen-space ray marching for opaque scene intersections. Runtime depth behavior still requires Iris validation. |

The final shader writes to the backbuffer. No history buffer, image, custom texture,
mipmap chain, half-resolution target, or buffer clear override is configured.
